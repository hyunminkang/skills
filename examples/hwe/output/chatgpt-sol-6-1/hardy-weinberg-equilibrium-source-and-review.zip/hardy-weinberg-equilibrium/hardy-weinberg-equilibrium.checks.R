# Run with: Rscript hardy-weinberg-equilibrium.checks.R
check <- function(id, ok) {
  if (!isTRUE(ok)) stop("check failed: ", id, call. = FALSE)
  cat("ok", id, "\n")
}
cat(R.version.string, "\n")
# ---- hwe-004
local({
  nAA <- 12
  nAB <- 16
  nBB <- 12
  N <- nAA + nAB + nBB
  pA <- (2 * nAA + nAB) / (2 * N)
  print(pA)
  check("hwe-004", isTRUE(all.equal(pA, 0.5)))
})
# ---- hwe-015
local({
  p <- c(A = 0.20, B = 0.30, C = 0.50)
  heterozygosity <- 1 - sum(p^2)
  print(round(heterozygosity, 2))
  check("hwe-015", isTRUE(all.equal(heterozygosity, 0.62)))
})
# ---- hwe-022
local({
  observed <- c(AA = 40, AB = 40, BB = 20)
  N <- sum(observed)
  p <- (2 * observed["AA"] + observed["AB"]) / (2 * N)
  expected_AB <- 2 * p * (1 - p) * N
  print(unname(expected_AB))
  check("hwe-022", isTRUE(all.equal(unname(expected_AB), 48)))
})
cat("All R checks passed\n")
