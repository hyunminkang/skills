# Hardy-Weinberg Equilibrium - Lecture 02 Draft Bank

Built 2026-10-11 by the canvas-quizbank skill.

## The two downloads

- `hardy-weinberg-equilibrium.qti.zip`: import this into Canvas (see below).
- `hardy-weinberg-equilibrium-source-and-review.zip`: this folder. Keep it: the YAML is the source for every later change, rebuild and sync.

## Files in this folder

- `hardy-weinberg-equilibrium.yaml`: the bank; edit this, never the QTI file
- `hardy-weinberg-equilibrium.review.md`: every item with its answer marked; unverified items first
- `hardy-weinberg-equilibrium.checks.R`: the code that verified the items (one section per item)
- `hardy-weinberg-equilibrium.checks.py`: the code that verified the items (one section per item)
- `README.md`: this file
- `figures/`: images used by the items

## Summary

- 25 items: 8 easy, 12 medium, 5 hard
- types: 20 multiple_choice, 2 multiple_answers, 2 numerical, 1 true_false
- verified by running code: 14 of 25

Not verified by execution (check these first):

- hwe-001: Conceptual or source-figure interpretation: checked against the cited slides; no executable result to verify.
- hwe-003: Conceptual or source-figure interpretation: checked against the cited slides; no executable result to verify.
- hwe-004: Rscript is unavailable in this environment. Base-R checks are supplied for instructor execution; output was reviewed analytically.
- hwe-006: Conceptual or source-figure interpretation: checked against the cited slides; no executable result to verify.
- hwe-011: Conceptual or source-figure interpretation: checked against the cited slides; no executable result to verify.
- hwe-015: Rscript is unavailable in this environment. Base-R checks are supplied for instructor execution; output was reviewed analytically.
- hwe-017: Conceptual or source-figure interpretation: checked against the cited slides; no executable result to verify.
- hwe-018: Conceptual or source-figure interpretation: checked against the cited slides; no executable result to verify.
- hwe-019: Conceptual or source-figure interpretation: checked against the cited slides; no executable result to verify.
- hwe-021: Conceptual or source-figure interpretation: checked against the cited slides; no executable result to verify.
- hwe-022: Rscript is unavailable in this environment. Base-R checks are supplied for instructor execution; output was reviewed analytically.

## Notes

## Coverage and review priorities

Exactly 25 items were drafted, following the requested approximate size rather than adding an extra 30% for trimming. All are `draft` and worth one point by default.

| Section | Slides | Items | Easy / medium / hard |
|---|---|---:|---|
| Alleles and genotype frequencies | 7-11 | 5 | 4 / 1 / 0 |
| HWE assumptions and random gamete union | 12-17 | 7 | 2 / 3 / 2 |
| Recessive inheritance, multiple alleles, inbreeding | 18-20 | 5 | 1 / 4 / 0 |
| Quality control and HWE testing | 21-34 | 8 | 1 / 4 / 3 |
| Total | | 25 | 8 / 12 / 5 |

Types: 20 multiple choice, 2 multiple-answer, 2 numerical, 1 true/false. Canvas Numerical items implement the requested short answers with numeric responses. Multiple-answer partial-credit behavior depends on the instructor's Canvas quiz settings.

The presumed audience is an introductory graduate biostatistics/genetics class, inferred from Biostatistics 666 and the lecture's exact-test material. Questions cover the substantive lecture; historical names, reading citations, prior/next-lecture content, and memorization of the specific GWAS filtering thresholds are omitted.

The code snippets are original R and Python applications of the mathematical content, not code transcribed from the slides. Only base R and Python's standard library are needed to answer the code items. The probability-plot regeneration additionally uses matplotlib.

Item hwe-012 applies independent gamete union to unequal sex-specific allele frequencies to illustrate why the lecture's equality assumption matters. Item hwe-017 interprets the inbreeding discussion without introducing an untaught inbreeding-coefficient formula. The disease items use an explicitly stated simplified recessive model, not clinical risk guidance.

## Verification

- Fourteen computational items passed the supplied Python checks: hwe-002, 005, 007, 008, 009, 010, 012, 013, 014, 016, 020, 023, 024, 025.
- Rscript is unavailable here. Items hwe-004, hwe-015, and hwe-022 were reviewed analytically but marked `verified: no`; run the supplied `.checks.R` before assigning these questions. The R snippets have not been verified by translation to Python.
- Eight conceptual or source-image items are marked `verified: no` because execution is not applicable: hwe-001, 003, 006, 011, 017, 018, 019, 021. Their keys and explanations were checked against their source slides.
- The source YAML validator reported zero errors and zero warnings. The QTI package was checked against the YAML, including keys, item types, and image references. A live import into the instructor's Canvas instance was not performed.

## Figures and equations

- `figures/genotype-calling-slide32.png` is an exact crop of the two cluster plots from slide 32 of the instructor-supplied PDF. The user-supplied lecture is the source; underlying figure permissions were not independently determined.
- `figures/exact-test-probabilities.png` is an original plot. Every probability was recomputed from the slide 25 conditional formula. Hatching identifies the observed bar without relying on color.
- Both figures have descriptive alt text. Math uses Canvas equation-image markup; R and Python retain code-block formatting in the QTI.

## Reviewing and importing

Start with the answer-marked `.review.md` or the standalone `.review.html` included in this folder. The HTML opens offline with embedded equations and figures; the Markdown and YAML remain the editable source.

Import the QTI into a temporary unpublished quiz or item bank first and inspect hwe-002, 004, 006, 011, 013, 018, 024, and 025 to check numeric responses, code, multiple-answer keys, true/false, images, and equations. Use the full bank itself for this initial import check.

After review, provide this source-and-review ZIP (or its YAML) plus the kept item IDs or a Canvas export, and the retained set can be synced without changing IDs.

## Import into Canvas

- New Quizzes: in a quiz, open **Item Banks**, create a new bank, then **⋮ → Import Content** and upload the `.qti.zip`.
- Classic Quizzes: **Settings → Import Course Content → QTI .zip file**.
- Each item's title starts with its id; its feedback ends with its source.

## After you review it in Canvas

Delete the items that do not fit, then give the agent (with the canvas-quizbank skill) this folder's YAML plus a Canvas export of what is left, or a text file of the remaining titles. It marks kept items `reviewed` and deleted ones `removed`, so they never come back in a rebuild.
