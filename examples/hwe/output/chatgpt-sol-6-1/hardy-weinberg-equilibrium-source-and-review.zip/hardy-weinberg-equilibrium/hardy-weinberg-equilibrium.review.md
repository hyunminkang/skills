# Hardy-Weinberg Equilibrium - Lecture 02 Draft Bank

25 items in the package (8 easy, 12 medium, 5 hard; 20 multiple_choice, 2 multiple_answers, 2 numerical, 1 true_false; 25 draft; verified 14 run, 11 no)

## Check these first

- **hwe-001**: not verified by execution (Conceptual or source-figure interpretation: checked against the cited slides; no executable result to verify.)
- **hwe-003**: not verified by execution (Conceptual or source-figure interpretation: checked against the cited slides; no executable result to verify.)
- **hwe-004**: not verified by execution (Rscript is unavailable in this environment. Base-R checks are supplied for instructor execution; output was reviewed analytically.)
- **hwe-006**: not verified by execution (Conceptual or source-figure interpretation: checked against the cited slides; no executable result to verify.)
- **hwe-011**: not verified by execution (Conceptual or source-figure interpretation: checked against the cited slides; no executable result to verify.)
- **hwe-015**: not verified by execution (Rscript is unavailable in this environment. Base-R checks are supplied for instructor execution; output was reviewed analytically.)
- **hwe-017**: not verified by execution (Conceptual or source-figure interpretation: checked against the cited slides; no executable result to verify.)
- **hwe-018**: not verified by execution (Conceptual or source-figure interpretation: checked against the cited slides; no executable result to verify.)
- **hwe-019**: not verified by execution (Conceptual or source-figure interpretation: checked against the cited slides; no executable result to verify.)
- **hwe-021**: not verified by execution (Conceptual or source-figure interpretation: checked against the cited slides; no executable result to verify.)
- **hwe-022**: not verified by execution (Rscript is unavailable in this environment. Base-R checks are supplied for instructor execution; output was reviewed analytically.)

## 1. hwe-001 — What allele frequency counts
`allele-frequency-denominator` `easy` `draft` `verified: no`
*Source: 666.02.pdf, slides 7-8*

At an autosomal locus, each of 200 diploid individuals contributes two allele copies.

What is the denominator when estimating the frequency of allele $A$ from this sample?

- **A.** 200 individuals
- **B.** 400 allele copies **✅**
- **C.** 3 genotype classes
- **D.** 100 mating pairs

> An allele frequency is the proportion of chromosome copies carrying the allele. There are two copies per diploid individual, so the denominator is 400; individuals, genotype classes, and mating pairs are different counting units.

## 2. hwe-002 — Number of unordered genotypes
`count-genotypes` `easy` `draft` `numerical` `verified: run`
*Source: 666.02.pdf, slides 9*

A diploid autosomal locus has four distinct alleles. Genotypes are unordered: $A/B$ and $B/A$ are the same genotype.

How many distinct genotypes are possible? Enter an integer.

**Answer:** 10 ✅

> There are four homozygotes and six distinct heterozygotes, giving 10 genotypes. Equivalently, for $k=4$ alleles, $k(k+1)/2=10$; counting both allele orders would overcount heterozygotes.

## 3. hwe-003 — Recognizing a heterozygote
`classify-genotypes` `easy` `draft` `verified: no`
*Source: 666.02.pdf, slides 9-10*

An autosomal locus has alleles $A$, $B$, and $C$.

Which genotype is heterozygous?

- **A.** $A/A$
- **B.** $C/C$
- **C.** $B/B$
- **D.** $A/C$ **✅**

> A heterozygote carries two different alleles, as in $A/C$. Each other option contains two copies of the same allele and is homozygous.

## 4. hwe-004 — Allele counting in R
`estimate-allele-frequency` `medium` `draft` `verified: no`
*Source: 666.02.pdf, slides 11, 22*

The counts refer to diploid individuals at an autosomal locus.

```r
nAA <- 12
nAB <- 16
nBB <- 12
N <- nAA + nAB + nBB
pA <- (2 * nAA + nAB) / (2 * N)
print(pA)
```

What value does the last line print?

- **A.** `0.50` **✅**
- **B.** `0.30`
- **C.** `0.40`
- **D.** `1.00`

> Each $AA$ individual contributes two $A$ copies and each $AB$ individual contributes one. The estimate is $(2\times12+16)/(2\times40)=0.50$; 0.30 counts only $AA$ individuals, 0.40 is the heterozygote fraction, and 1.00 uses the wrong denominator.

## 5. hwe-005 — Genotype frequencies to allele frequencies
`convert-genotype-frequencies` `easy` `draft` `verified: run`
*Source: 666.02.pdf, slides 11*

The dictionary contains observed genotype frequencies; no equilibrium assumption is made.

```python
freq = {"AA": 0.40, "AB": 0.50, "BB": 0.10}
p_A = freq["AA"] + 0.5 * freq["AB"]
print(round(p_A, 2))
```

What does the last line print?

- **A.** `0.40`
- **B.** `0.65` **✅**
- **C.** `0.90`
- **D.** `0.25`

> The $A$ allele frequency is $0.40+0.5(0.50)=0.65$. The alternatives omit the heterozygotes, give every heterozygote two $A$ copies, or count only the $A$ contribution from heterozygotes; this conversion does not require HWE.

## 6. hwe-006 — Assumptions of the lecture model
`identify-hwe-assumptions` `medium` `draft` `multiple_answers` `verified: no`
*Source: 666.02.pdf, slides 12-13*

Consider the lecture's Hardy-Weinberg model for a diploid, sexual organism at an autosomal locus.

Which conditions are assumptions of that model? Select all that apply.

- **A.** Random mating with respect to the locus. **✅**
- **B.** Equal frequencies of all alleles at the locus.
- **C.** A large population with negligible genetic drift. **✅**
- **D.** Absence of genotype-dependent natural selection. **✅**
- **E.** The same genotype in every individual.

> Random mating, a large population, and no natural selection are assumptions listed in the lecture. HWE allows unequal allele frequencies and a mixture of genotypes; it does not require either equal allele frequencies or genetic uniformity.

## 7. hwe-007 — Frequency of a mating type
`calculate-random-mating-frequency` `medium` `draft` `verified: run`
*Source: 666.02.pdf, slides 14*

The genotype frequencies are $f_{AA}=0.40$, $f_{AB}=0.50$, and $f_{BB}=0.10$ in each sex. Pairing is random.

What fraction of mating pairs have one $AA$ parent and one $AB$ parent, counting both parent orders?

- **A.** 0.20
- **B.** 0.25
- **C.** 0.90
- **D.** 0.40 **✅**

> There are two parent orders, so the frequency is $2f_{AA}f_{AB}=2(0.40)(0.50)=0.40$. The value 0.20 counts only one order, 0.25 describes two $AB$ parents, and 0.90 adds frequencies instead of multiplying independent parental draws.

## 8. hwe-008 — Mendelian segregation in Python
`apply-mendelian-segregation` `medium` `draft` `verified: run`
*Source: 666.02.pdf, slides 15*

Both parents have genotype $A/B$. The four ordered gamete pairs in the code are equally likely.

```python
from itertools import product

gametes = ["A", "B"]
offspring = list(product(gametes, gametes))
heterozygotes = sum(a != b for a, b in offspring)
print(heterozygotes / len(offspring))
```

What does the last line print?

- **A.** `0.25`
- **B.** `1.0`
- **C.** `0.5` **✅**
- **D.** `0.0`

> Two of the four pairs, $(A,B)$ and $(B,A)$, are heterozygous, so the result is 0.5. The value 0.25 counts one order only, 1.0 assumes all offspring resemble their heterozygous parents, and 0.0 ignores segregation.

## 9. hwe-009 — Probability of an AA offspring
`derive-homozygote-frequency` `easy` `draft` `verified: run`
*Source: 666.02.pdf, slides 16-17*

A gamete carries allele $A$ with probability $p$ and allele $B$ with probability $q=1-p$. The two gametes forming an offspring are independent and have the same allele probabilities.

Which expression is the probability of genotype $A/A$?

- **A.** $2pq$
- **B.** $p^2$ **✅**
- **C.** $q^2$
- **D.** $p+q$

> The offspring must receive $A$ from both gametes, giving $p\times p=p^2$. The expression $2pq$ counts heterozygotes, $q^2$ counts $BB$, and $p+q=1$ is the probability of either allele in a single gamete.

## 10. hwe-010 — One generation from homozygous parents
`understand-one-generation-equilibrium` `hard` `draft` `verified: run`
*Source: 666.02.pdf, slides 15-17*

Initially, 25% of a large population is $A/A$ and 75% is $B/B$, with no heterozygotes. The locus is autosomal, mating is random, segregation is Mendelian, and neither genotype nor gamete is selected.

What are the expected offspring genotype frequencies in the order $(AA, AB, BB)$?

- **A.** $(4/16,0,12/16)$
- **B.** $(4/16,8/16,4/16)$
- **C.** $(1/16,6/16,9/16)$ **✅**
- **D.** $(8/16,0,8/16)$

> The allele frequencies are $p_A=1/4$ and $p_B=3/4$, despite the initial absence of heterozygotes. Independent gamete union gives $(1/16,6/16,9/16)$ in one generation; copying parental frequencies preserves disequilibrium, while the other alternatives incorrectly impose equal allele frequencies.

## 11. hwe-011 — Does HWE require equal allele frequencies?
`separate-equilibrium-from-allele-balance` `easy` `draft` `true_false` `verified: no`
*Source: 666.02.pdf, slides 8, 17*

True or false: a biallelic population can satisfy Hardy-Weinberg equilibrium only when both alleles have frequency 0.5.

**Answer:** False ✅

> False. HWE describes the relationship between allele and genotype frequencies, not equality of the allele frequencies; any valid pair $p$ and $1-p$ can generate equilibrium genotype frequencies.

## 12. hwe-012 — Unequal allele frequencies between sexes
`apply-sex-specific-gamete-probabilities` `hard` `draft` `verified: run`
*Source: 666.02.pdf, slides 13, 16*

At an autosomal locus, allele $A$ has frequency 0.80 among maternal gametes and 0.20 among paternal gametes. Gametes unite independently, with no selection.

What is the expected frequency of $AA$ offspring?

- **A.** 0.16 **✅**
- **B.** 0.25
- **C.** 0.64
- **D.** 0.04

> An $AA$ offspring requires one maternal and one paternal $A$, so the frequency is $0.80\times0.20=0.16$. Squaring the pooled frequency gives 0.25 and incorrectly assumes equal gamete distributions; 0.64 and 0.04 square just one sex's frequency.

## 13. hwe-013 — Carrier proportion for a recessive allele
`estimate-carrier-frequency` `medium` `draft` `numerical` `verified: run`
*Source: 666.02.pdf, slides 18*

In a simplified fully penetrant recessive model, allele $a$ has frequency 0.02 and allele $A$ has frequency 0.98. Assume Hardy-Weinberg equilibrium; carriers are $A/a$ heterozygotes.

Enter the expected carrier proportion as a decimal, rounded to four decimal places (not a percentage).

**Answer:** 0.0392 ± 5e-05 ✅

> The carrier proportion is $2(0.98)(0.02)=0.0392$, or 3.92%. Squaring 0.02 would instead give the affected homozygote proportion; entering 3.92 would use percentage units rather than the requested proportion.

## 14. hwe-014 — Affected births under a recessive model
`estimate-recessive-homozygote-frequency` `easy` `draft` `verified: run`
*Source: 666.02.pdf, slides 18*

A recessive disease occurs only in $a/a$ individuals, with full penetrance. Allele $a$ has frequency 0.10, and the population is in Hardy-Weinberg equilibrium.

What is the expected proportion of affected births?

- **A.** 0.10
- **B.** 0.20
- **C.** 0.18
- **D.** 0.01 **✅**

> Affected births have genotype $a/a$, with frequency $0.10^2=0.01$. The value 0.10 is the allele frequency, 0.20 doubles that frequency without considering the other allele, and 0.18 is the carrier proportion.

## 15. hwe-015 — Total heterozygosity with three alleles
`extend-hwe-to-multiple-alleles` `medium` `draft` `verified: no`
*Source: 666.02.pdf, slides 19*

The vector gives the allele frequencies at a three-allele locus in Hardy-Weinberg equilibrium.

```r
p <- c(A = 0.20, B = 0.30, C = 0.50)
heterozygosity <- 1 - sum(p^2)
print(round(heterozygosity, 2))
```

What does the last line print?

- **A.** `0.38`
- **B.** `0.62` **✅**
- **C.** `0.50`
- **D.** `1.00`

> The homozygote frequencies sum to $0.20^2+0.30^2+0.50^2=0.38$, so the heterozygote proportion is 0.62. The value 0.38 counts homozygotes, 0.50 is one allele's frequency, and 1.00 ignores homozygotes altogether.

## 16. hwe-016 — A particular multiallelic heterozygote
`calculate-multiallelic-genotype-frequency` `medium` `draft` `verified: run`
*Source: 666.02.pdf, slides 19*

A locus has alleles $D$, $E$, and $F$ with frequencies 0.25, 0.40, and 0.35. Assume Hardy-Weinberg equilibrium.

What is the expected frequency of genotype $D/F$?

- **A.** 0.0875
- **B.** 0.6000
- **C.** 0.1750 **✅**
- **D.** 0.0625

> Both gamete orders contribute, giving $2(0.25)(0.35)=0.1750$. The value 0.0875 counts one order, 0.6000 adds allele frequencies, and 0.0625 is the $D/D$ homozygote frequency.

## 17. hwe-017 — Why inbreeding matters
`interpret-inbreeding` `medium` `draft` `verified: no`
*Source: 666.02.pdf, slides 19-20*

Compare an inbred population with a randomly mating population at the same biallelic autosomal locus, holding allele frequencies fixed.

What genotype pattern is expected from inbreeding?

- **A.** More homozygotes and fewer heterozygotes. **✅**
- **B.** Fewer homozygotes and more heterozygotes.
- **C.** Equal frequencies of the three genotypes.
- **D.** Loss of the rarer allele in one generation.

> Relatives are more likely to carry copies inherited from a common ancestor, increasing the chance of matching alleles in offspring. This produces excess homozygosity at fixed allele frequencies; it does not imply equal genotype frequencies or immediate loss of an allele.

## 18. hwe-018 — Reading the genotype-calling figure
`diagnose-genotyping-artifact` `medium` `draft` `verified: no`
*Source: 666.02.pdf, slides 21, 31-32*

The two panels show calls for the same underlying intensity clusters. In the right panel the three groups are called $AA$, $AB$, and $BB$; in the left panel the high-$A$, low-$B$ group is called $AB$ instead of $AA$.

![Two genotype-cluster scatterplots with allele A intensity on the horizontal axis and allele B intensity on the vertical axis. On the right, triangles at low A/high B are BB, squares in the middle are AB, and diamonds at high A/low B are AA. On the left, the middle and high A/low B groups are both marked as AB squares.](figures/genotype-calling-slide32.png)

Relative to the right panel, what does the left panel's calling error do to the observed heterozygote count?

- **A.** It leaves the count unchanged.
- **B.** It removes every heterozygote.
- **C.** It lowers the count.
- **D.** It raises the count. **✅**

> Calling the $AA$ cluster as $AB$ adds homozygotes to the observed heterozygote class. The count therefore increases, illustrating how a calling artifact can create excess heterozygotes; unchanged or lower counts would require a different misclassification pattern.

## 19. hwe-019 — Interpreting an HWE departure
`identify-causes-of-hwe-deviation` `medium` `draft` `multiple_answers` `verified: no`
*Source: 666.02.pdf, slides 21, 34*

A marker shows a substantial departure from Hardy-Weinberg expectations in a genetic study.

Which mechanisms listed in the lecture could explain the departure? Select all that apply.

- **A.** A systematic genotyping error. **✅**
- **B.** Previously unrecognized population structure. **✅**
- **C.** A perfectly random gamete union with no other disturbance.
- **D.** A trait association in an ascertained case-control sample. **✅**
- **E.** Relabeling the two alleles consistently throughout the data.

> Genotyping errors, population structure, and trait association in an ascertained case-control study are all listed explanations. Ideal random gamete union generates HWE, and consistently swapping allele names only swaps the two homozygote labels; neither mechanism explains a departure.

## 20. hwe-020 — Feasible heterozygote counts
`enumerate-conditional-exact-test-support` `hard` `draft` `verified: run`
*Source: 666.02.pdf, slides 22, 24-26*

An exact HWE test conditions on $N=5$ diploid individuals and $n_A=3$ copies of allele $A$. Genotype counts must be nonnegative integers.

```python
N = 5
n_A = 3
possible = []
for n_AB in range(n_A + 1):
    n_AA = (n_A - n_AB) / 2
    n_BB = N - n_AA - n_AB
    if n_AA >= 0 and n_BB >= 0 and n_AA.is_integer() and n_BB.is_integer():
        possible.append(n_AB)
print(possible)
```

What list does the last line print?

- **A.** `[1, 3]` **✅**
- **B.** `[0, 2]`
- **C.** `[0, 1, 2, 3]`
- **D.** `[3]`

> Since $n_A=2n_{AA}+n_{AB}$, $n_{AB}$ must be odd when $n_A=3$. Both 1 and 3 produce valid genotype counts; even counts would require fractional homozygote counts, and retaining only 3 wrongly excludes the configuration with one $AA$ individual.

## 21. hwe-021 — Choosing a test for a rare allele
`recognize-chi-square-limitations` `easy` `draft` `verified: no`
*Source: 666.02.pdf, slides 23-24, 34*

A marker's rare allele produces very small expected counts in one or more genotype classes.

Which approach does the lecture recommend to assess HWE more reliably?

- **A.** Apply a normal test to allele labels.
- **B.** Drop the rare homozygotes before testing.
- **C.** Use an exact test of genotype proportions. **✅**
- **D.** Use an uncorrected chi-square approximation.

> The chi-square approximation can be inaccurate when an allele is rare, so the lecture recommends an exact test. Dropping a genotype class changes the sample, a normal test on labels is unrelated to the genotype distribution, and the uncorrected approximation retains the stated limitation.

## 22. hwe-022 — Expected count from observed genotypes
`compute-expected-counts` `medium` `draft` `verified: no`
*Source: 666.02.pdf, slides 22-23*

The code estimates the allele frequency from observed counts, then computes the expected number of heterozygotes under HWE.

```r
observed <- c(AA = 40, AB = 40, BB = 20)
N <- sum(observed)
p <- (2 * observed["AA"] + observed["AB"]) / (2 * N)
expected_AB <- 2 * p * (1 - p) * N
print(unname(expected_AB))
```

What value does the last line print?

- **A.** `40`
- **B.** `36`
- **C.** `16`
- **D.** `48` **✅**

> The estimated $A$ frequency is $(80+40)/200=0.60$, giving $2(0.60)(0.40)(100)=48$ expected heterozygotes. The value 40 is the observed count; 36 and 16 are expected $AA$ and $BB$ counts.

## 23. hwe-023 — A chi-square discrepancy calculation
`calculate-chi-square-statistic` `medium` `draft` `verified: run`
*Source: 666.02.pdf, slides 23*

A biallelic sample contains 100 diploid individuals. Its observed counts are ordered $(AA,AB,BB)$; the expected counts under HWE use the allele frequency estimated from that sample.

$$X^2=\sum_g\frac{(O_g-E_g)^2}{E_g},$$

where $O_g$ and $E_g$ are the observed and expected counts for genotype $g$.

```python
observed = [30, 40, 30]
expected = [25, 50, 25]
statistic = sum((o - e) ** 2 / e for o, e in zip(observed, expected))
print(statistic)
```

What does the last line print?

- **A.** `2.0`
- **B.** `4.0` **✅**
- **C.** `20.0`
- **D.** `150.0`

> The contributions are $25/25$, $100/50$, and $25/25$, summing to 4.0. The value 2.0 keeps only the heterozygote term, 20.0 adds absolute discrepancies, and 150.0 omits the expected-count denominators.

## 24. hwe-024 — Conditional configuration probability
`apply-exact-hwe-probability` `hard` `draft` `verified: run`
*Source: 666.02.pdf, slides 25-26*

For $N$ individuals, let $n_A,n_B$ be allele-copy counts and $n_{AA},n_{AB},n_{BB}$ be genotype counts. Under HWE, conditional on the allele counts,

$$P(n_{AB}\mid N,n_A)=\frac{2^{n_{AB}}N!}{n_{AA}!n_{AB}!n_{BB}!}\frac{n_A!n_B!}{(2N)!}.$$

```python
from math import factorial

N, n_A, n_B = 3, 2, 4
n_AA, n_AB, n_BB = 1, 0, 2
probability = (
    2 ** n_AB * factorial(N)
    / (factorial(n_AA) * factorial(n_AB) * factorial(n_BB))
    * factorial(n_A) * factorial(n_B) / factorial(2 * N)
)
print(round(probability, 2))
```

What does the last line print?

- **A.** `1.0`
- **B.** `0.8`
- **C.** `0.4`
- **D.** `0.2` **✅**

> There are 15 arrangements of two $A$ copies among six allele positions, and three correspond to one $AA$ plus two $BB$ individuals, so the conditional probability is $3/15=0.2$. The value 0.8 is the alternative heterozygote configuration's probability; 0.4 and 1.0 result from incorrect combinatorial weighting or treating an observed configuration as certain.

## 25. hwe-025 — Reading an exact-test probability plot
`compute-probability-ordered-exact-p-value` `hard` `draft` `verified: run`
*Source: 666.02.pdf, slides 24, 27*

An exact HWE test conditions on $N=4$ individuals and four copies of each allele. The plot gives the conditional probabilities of every feasible heterozygote count. The observed count is $n_{AB}=4$, marked with hatching.

![Bar plot of conditional probability versus heterozygote count. Bars at counts 0, 2, and 4 have heights 3/35, 24/35, and 8/35. The bar at count 4 is hatched and marked observed.](figures/exact-test-probabilities.png)

Using a two-sided probability-ordered exact test, which expression is the p-value?

- **A.** $8/35$
- **B.** $16/35$
- **C.** $11/35$ **✅**
- **D.** $27/35$

> Sum the probabilities of all configurations no more probable than the observed one. The counts 0 and 4 qualify, giving $(3+8)/35=11/35$; 8/35 is just the observed probability, 16/35 doubles it, and 27/35 includes the high-probability count 2 while excluding the observed count.
