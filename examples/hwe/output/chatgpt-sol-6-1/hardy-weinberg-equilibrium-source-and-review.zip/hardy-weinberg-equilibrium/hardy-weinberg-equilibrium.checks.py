import contextlib
import io
import sys
from fractions import Fraction
from itertools import combinations_with_replacement, product
from math import comb, factorial, isclose
from pathlib import Path

def hwe_prob(N, n_A, h):
    n_B=2*N-n_A
    aa=(n_A-h)//2
    bb=(n_B-h)//2
    return Fraction(2**h*factorial(N)*factorial(n_A)*factorial(n_B), factorial(aa)*factorial(h)*factorial(bb)*factorial(2*N))

print(sys.version)


# ---- hwe-002
def _hwe_002():
    assert 4*(4+1)//2 == 10
    assert len(list(combinations_with_replacement(range(4), 2))) == 10
    print("ok", 'hwe-002')
_hwe_002()


# ---- hwe-005
def _hwe_005():
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer):
        exec('freq = {"AA": 0.40, "AB": 0.50, "BB": 0.10}\np_A = freq["AA"] + 0.5 * freq["AB"]\nprint(round(p_A, 2))', {})
    output = buffer.getvalue()
    assert output.strip() == "0.65"
    print("ok", 'hwe-005')
_hwe_005()


# ---- hwe-007
def _hwe_007():
    assert isclose(2*0.4*0.5, 0.4)
    assert not any(isclose(2*0.4*0.5, x) for x in [0.2,0.25,0.9])
    print("ok", 'hwe-007')
_hwe_007()


# ---- hwe-008
def _hwe_008():
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer):
        exec('from itertools import product\n\ngametes = ["A", "B"]\noffspring = list(product(gametes, gametes))\nheterozygotes = sum(a != b for a, b in offspring)\nprint(heterozygotes / len(offspring))', {})
    output = buffer.getvalue()
    assert output.strip() == "0.5"
    print("ok", 'hwe-008')
_hwe_008()


# ---- hwe-009
def _hwe_009():
    assert isclose(0.3*0.3,0.3**2)
    assert all(not isclose(0.3**2,x) for x in [2*0.3*0.7,0.7**2,1])
    print("ok", 'hwe-009')
_hwe_009()


# ---- hwe-010
def _hwe_010():
    p=0.25
    assert [p*p,2*p*(1-p),(1-p)**2] == [1/16,6/16,9/16]
    assert isclose(1/16+0.5*6/16,p)
    print("ok", 'hwe-010')
_hwe_010()


# ---- hwe-012
def _hwe_012():
    assert isclose(0.8*0.2,0.16)
    assert all(not isclose(0.8*0.2,x) for x in [0.25,0.64,0.04])
    print("ok", 'hwe-012')
_hwe_012()


# ---- hwe-013
def _hwe_013():
    assert isclose(2*0.98*0.02,0.0392)
    assert round(2*0.98*0.02,4) == 0.0392
    print("ok", 'hwe-013')
_hwe_013()


# ---- hwe-014
def _hwe_014():
    assert isclose(0.1**2,0.01)
    assert all(not isclose(0.1**2,x) for x in [0.1,0.2,0.18])
    print("ok", 'hwe-014')
_hwe_014()


# ---- hwe-016
def _hwe_016():
    assert isclose(2*0.25*0.35,0.175)
    assert all(not isclose(2*0.25*0.35,x) for x in [0.0875,0.6,0.0625])
    print("ok", 'hwe-016')
_hwe_016()


# ---- hwe-020
def _hwe_020():
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer):
        exec('N = 5\nn_A = 3\npossible = []\nfor n_AB in range(n_A + 1):\n    n_AA = (n_A - n_AB) / 2\n    n_BB = N - n_AA - n_AB\n    if n_AA >= 0 and n_BB >= 0 and n_AA.is_integer() and n_BB.is_integer():\n        possible.append(n_AB)\nprint(possible)', {})
    output = buffer.getvalue()
    assert output.strip() == "[1, 3]"
    print("ok", 'hwe-020')
_hwe_020()


# ---- hwe-023
def _hwe_023():
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer):
        exec('observed = [30, 40, 30]\nexpected = [25, 50, 25]\nstatistic = sum((o - e) ** 2 / e for o, e in zip(observed, expected))\nprint(statistic)', {})
    output = buffer.getvalue()
    assert output.strip() == "4.0"
    assert (2*30+40)/(2*100) == 0.5
    print("ok", 'hwe-023')
_hwe_023()


# ---- hwe-024
def _hwe_024():
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer):
        exec('from math import factorial\n\nN, n_A, n_B = 3, 2, 4\nn_AA, n_AB, n_BB = 1, 0, 2\nprobability = (\n    2 ** n_AB * factorial(N)\n    / (factorial(n_AA) * factorial(n_AB) * factorial(n_BB))\n    * factorial(n_A) * factorial(n_B) / factorial(2 * N)\n)\nprint(round(probability, 2))', {})
    output = buffer.getvalue()
    assert output.strip() == "0.2"
    assert comb(6,2)==15
    assert factorial(3)//(factorial(1)*factorial(2))==3
    print("ok", 'hwe-024')
_hwe_024()


# ---- hwe-025
def _hwe_025():
    weights=[Fraction(3,35),Fraction(24,35),Fraction(8,35)]
    assert sum(weights)==1
    assert sum(w for w in weights if w<=weights[2])==Fraction(11,35)
    assert weights==[hwe_prob(4,4,h) for h in [0,2,4]]
    print("ok", 'hwe-025')
_hwe_025()


# ---- hwe-025: recreate the precise probability figure
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig, ax = plt.subplots(figsize=(7,4.3), dpi=150)
xs=[0,2,4]
values=[float(hwe_prob(4,4,h)) for h in xs]
bars=ax.bar(xs, values, width=0.8, color='#b9c8db',edgecolor='#253c58', linewidth=1.5)
bars[2].set_hatch('///')
for bar,label in zip(bars,['3/35','24/35','8/35']):
    ax.text(bar.get_x()+bar.get_width()/2,bar.get_height()+0.025,label,ha='center',fontsize=12)
ax.text(4,values[2]+0.09,'Observed',ha='center',fontsize=11)
ax.set(xlabel='Number of heterozygotes', ylabel='Conditional probability', xticks=xs, ylim=(0,0.86))
ax.tick_params(labelsize=11)
ax.xaxis.label.set_size(12)
ax.yaxis.label.set_size(12)
ax.spines[['top','right']].set_visible(False)
fig.tight_layout()
figures=Path(__file__).resolve().parent/'figures'
figures.mkdir(exist_ok=True)
fig.savefig(figures/'exact-test-probabilities.png')
plt.close(fig)
print('All Python checks passed; R checks require Rscript.')
