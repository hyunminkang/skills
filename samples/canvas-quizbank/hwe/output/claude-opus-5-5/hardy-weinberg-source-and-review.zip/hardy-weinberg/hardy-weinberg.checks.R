# hardy-weinberg.checks.R — run: Rscript hardy-weinberg.checks.R
check <- function(id, ok) {
  if (!isTRUE(ok)) stop("check failed: ", id, call. = FALSE)
  cat("ok", id, "\n")
}
cat(R.version.string, "\n")

# ---- hwe-002: allele frequency from genotype counts
local({
  out <- capture.output({
    counts <- c(AA = 36, AB = 48, BB = 16)
    pA <- (2 * counts["AA"] + counts["AB"]) / (2 * sum(counts))
    print(unname(pA))
  })
  check("hwe-002", identical(out, "[1] 0.6"))
})

# ---- hwe-022: recursive exact-test probabilities
local({
  het_probs <- function(N, nA) {
    nB  <- 2 * N - nA                     # assumes nA <= nB
    nAB <- seq(nA, 0, by = -2)            # possible heterozygote counts
    w <- numeric(length(nAB)); w[1] <- 1  # unnormalized weights
    for (i in seq_along(nAB)[-1]) {
      h   <- nAB[i - 1]
      nAA <- (nA - h) / 2
      nBB <- (nB - h) / 2
      w[i] <- w[i - 1] * h * (h - 1) / (4 * (nAA + 1) * (nBB + 1))
    }
    setNames(w / sum(w), nAB)
  }
  out <- capture.output(print(het_probs(N = 3, nA = 2)))
  cat(out, sep = "\n")
  # the distractor printouts are formatted as R would print them
  d1 <- capture.output(print(setNames(c(0.2, 0.8), c(2, 0))))
  d3 <- capture.output(print(setNames(c(2, 1) / 3, c(2, 0))))
  cat(d3, sep = "\n")
  # cross-check the recursion against the closed form on a larger case
  closed <- function(N, nA) {
    nB <- 2 * N - nA; h <- seq(nA, 0, by = -2)
    lp <- h * log(2) + lfactorial(N) - lfactorial((nA - h) / 2) - lfactorial(h) -
      lfactorial((nB - h) / 2) + lfactorial(nA) + lfactorial(nB) - lfactorial(2 * N)
    exp(lp)
  }
  check("hwe-022",
        identical(trimws(out), c("2   0", "0.8 0.2")) &&
        identical(trimws(d1), c("2   0", "0.2 0.8")) &&
        identical(trimws(d3), c("2         0", "0.6666667 0.3333333")) &&
        isTRUE(all.equal(unname(het_probs(100, 21)), closed(100, 21))))
})

cat("all checks passed\n")
