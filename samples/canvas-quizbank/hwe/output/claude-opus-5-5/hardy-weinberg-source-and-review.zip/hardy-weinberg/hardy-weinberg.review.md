# Hardy-Weinberg Equilibrium (Biostatistics 666, lecture 2)

26 items in the package (8 easy, 13 medium, 5 hard; 23 multiple_choice, 1 multiple_answers, 1 numerical, 1 true_false; 26 draft; verified 24 run, 2 no)

## Check these first

- **hwe-007**: not verified by execution (conceptual: nothing to execute)
- **hwe-015**: not verified by execution (conceptual: nothing to execute)

## 1. hwe-001 — Genotypes at a five-allele locus
`genotype-count` `easy` `draft` `verified: run`
*Source: Slides 9 and 12 (genotypes; n(n+1)/2 genotype frequencies)*

An autosomal locus in a diploid organism has $n = 5$ distinct alleles.
A genotype is the unordered pair of alleles an individual carries, so
$A/B$ and $B/A$ are the same genotype.

How many distinct genotypes are possible?

- **A.** $10$
- **B.** $25$
- **C.** $15$ **✅**
- **D.** $20$

> There are $n = 5$ homozygous genotypes plus $\binom{5}{2} = 10$
> heterozygous ones, $n(n+1)/2 = 15$ in all. $25 = n^2$ counts ordered
> pairs, so $A/B$ and $B/A$ are counted twice; $10$ counts only the
> heterozygotes; $20 = n(n-1)$ counts ordered heterozygous pairs.

## 2. hwe-002 — Allele frequency from genotype counts (R)
`allele-frequency-from-genotypes` `easy` `draft` `verified: run`
*Source: Slide 11 (genotype frequencies lead to allele frequencies)*

```r
counts <- c(AA = 36, AB = 48, BB = 16)
pA <- (2 * counts["AA"] + counts["AB"]) / (2 * sum(counts))
unname(pA)
```

What does the last line print?

- **A.** `[1] 0.36`
- **B.** `[1] 0.42`
- **C.** `[1] 0.84`
- **D.** `[1] 0.6` **✅**

> Each $AA$ individual carries two copies of $A$ and each $AB$ one, out of
> $2N = 200$ chromosomes: $(72 + 48)/200 = 0.6$, the same as
> $p_A = P_{AA} + \tfrac12 P_{AB} = 0.36 + 0.24$. $0.36$ is the $AA$
> genotype frequency, $0.84$ counts heterozygotes as whole $A$
> individuals, and $0.42$ forgets that $AA$ carries two copies.

## 3. hwe-003 — Allele frequency at a three-allele locus (Python)
`allele-frequency-from-genotypes` `medium` `draft` `verified: run`
*Source: Slides 10-11 (genotype frequencies with more than two alleles)*

```python
geno = {"AA": 0.10, "AB": 0.20, "AC": 0.30,
        "BB": 0.05, "BC": 0.15, "CC": 0.20}
pA = sum(f * g.count("A") / 2 for g, f in geno.items())
print(round(pA, 2))
```

The dictionary holds genotype frequencies at a locus with alleles
$A$, $B$ and $C$. What does the code print?

- **A.** `0.35` **✅**
- **B.** `0.6`
- **C.** `0.2`
- **D.** `0.1`

> `g.count("A") / 2` is the share of a genotype's two alleles that are
> $A$, so $p_A = P_{AA} + \tfrac12 P_{AB} + \tfrac12 P_{AC} =
> 0.10 + 0.10 + 0.15 = 0.35$. $0.6$ counts every genotype containing $A$
> in full, $0.2$ omits the $AC$ heterozygotes, and $0.1$ counts only the
> homozygotes.

## 4. hwe-004 — Same allele frequency, different genotypes
`genotype-vs-allele-frequencies` `easy` `draft` `verified: run`
*Source: Slides 11 and 17 (allele vs genotype frequencies; HWE proportions)*

Genotype frequencies at an autosomal locus with alleles $A$ and $B$:

| population | $P_{AA}$ | $P_{AB}$ | $P_{BB}$ |
|:--|--:|--:|--:|
| 1 | 0.40 | 0.20 | 0.40 |
| 2 | 0.25 | 0.50 | 0.25 |

Which statement is correct?

- **A.** Both have $p_A = 0.5$; both are in HWE proportions
- **B.** Both have $p_A = 0.5$; only population 1 is in HWE proportions
- **C.** Both have $p_A = 0.5$; only population 2 is in HWE proportions **✅**
- **D.** They differ in $p_A$; only population 2 is in HWE proportions

> In both, $p_A = P_{AA} + \tfrac12 P_{AB} = 0.5$. HWE proportions for
> $p_A = 0.5$ are $p_A^2 = 0.25$, $2p_Ap_B = 0.5$, $p_B^2 = 0.25$, which only
> population 2 matches; population 1 has a heterozygote deficit. Allele
> frequencies follow from genotype frequencies, but not the reverse
> unless HWE holds.

## 5. hwe-005 — Frequency of a mating type
`mating-type-frequencies` `easy` `draft` `verified: run`
*Source: Slide 14 (random mating: mating type frequencies)*

In a population with genotype frequencies $P_{AA}$, $P_{AB}$ and
$P_{BB}$ (the same in both sexes), individuals mate at random. Matings
are counted without regard to which parent is male, so
$AA \times AB$ includes both $AA$ father with $AB$ mother and the
reverse.

What is the frequency of $AA \times AB$ matings?

- **A.** $P_{AA}P_{AB}$
- **B.** $2P_{AA}P_{AB}$ **✅**
- **C.** $P_{AA} + P_{AB}$
- **D.** $\tfrac12 P_{AA}P_{AB}$

> Under random mating, the parents' genotypes are independent, so an
> $AA$ father and $AB$ mother occur with frequency $P_{AA}P_{AB}$, and the
> reverse with the same frequency: $2P_{AA}P_{AB}$ in total.
> $P_{AA}P_{AB}$ counts only one ordering; a sum of frequencies would
> describe "either parent", not a pair.

## 6. hwe-006 — Offspring homozygote frequency
`one-generation-derivation` `medium` `draft` `verified: run`
*Source: Slides 15-16 (offspring genotype frequencies)*

With random mating and Mendelian segregation, parents with genotype
frequencies $P_{AA}$, $P_{AB}$, $P_{BB}$ produce $AA$ offspring with
frequency

$$P'_{AA} = P_{AA}^2 + P_{AA}P_{AB} + \tfrac14 P_{AB}^2 .$$

Which expression is equal to $P'_{AA}$ for every choice of the
parental frequencies?

- **A.** $(P_{AA} + P_{AB})^2$
- **B.** $P_{AA}^2 + \tfrac14 P_{AB}^2$
- **C.** $P_{AA}(P_{AA} + P_{AB})$
- **D.** $(P_{AA} + \tfrac12 P_{AB})^2$ **✅**

> Expanding $(P_{AA} + \tfrac12 P_{AB})^2$ gives exactly the three
> terms, and $P_{AA} + \tfrac12 P_{AB} = p_A$, so $P'_{AA} = p_A^2$
> depends only on the allele frequency. $(P_{AA} + P_{AB})^2$ counts
> heterozygotes as fully $A$; the other two drop or halve the cross term
> and are not equal in general.

## 7. hwe-007 — Assumptions behind HWE
`assumptions` `medium` `draft` `multiple_answers` `verified: no`
*Source: Slide 13 (required assumptions)*

Consider an autosomal locus in a diploid, sexually reproducing species
with non-overlapping generations.

Which of the following are among the assumptions needed for genotype
frequencies to reach Hardy-Weinberg proportions? Select all that apply.

- **A.** Mating is random with respect to genotype at the locus **✅**
- **B.** The two alleles have equal frequencies, $p_A = p_B = 0.5$
- **C.** Genotypes at the locus do not affect survival or fertility **✅**
- **D.** Genotype frequencies are the same in males and females **✅**
- **E.** The locus has exactly two alleles

> HWE needs random mating, no selection (genotype does not affect
> survival or fertility), equal genotype frequencies in the two sexes,
> and a large population. It holds for any allele frequencies, and it
> extends to $k$ alleles by expanding $(p_1 + \dots + p_k)^2$, so neither
> $p_A = 0.5$ nor two alleles is required.

## 8. hwe-008 — Heterozygotes after one generation
`one-generation-derivation` `medium` `draft` `verified: run`
*Source: Slide 17 (equilibrium reached in one generation)*

A large population has, at an autosomal locus, genotype frequencies
$P_{AA} = 0.8$, $P_{AB} = 0$, $P_{BB} = 0.2$ in both sexes. The
population then mates at random for one generation, with no selection,
mutation or migration.

What proportion of the offspring are heterozygous $AB$?

- **A.** $0$
- **B.** $0.16$
- **C.** $0.32$ **✅**
- **D.** $0.64$

> $p_A = 0.8 + \tfrac12 \cdot 0 = 0.8$, and one round of random mating
> gives HWE proportions whatever the starting genotype frequencies, so
> $P'_{AB} = 2 p_A p_B = 2(0.8)(0.2) = 0.32$. $0$ assumes the parents'
> lack of heterozygotes carries over; $0.16$ forgets the factor 2;
> $0.64$ is $p_A^2$, the $AA$ frequency.

## 9. hwe-009 — Sexes with different allele frequencies
`assumptions` `hard` `draft` `verified: run`
*Source: Slide 13 (equal genotype frequencies among sexes)*

At an autosomal locus, every male in a large population is $AA$ and
every female is $BB$. The population mates at random.

What proportion of the offspring generation is heterozygous $AB$?

- **A.** $1$ **✅**
- **B.** $0.5$
- **C.** $0.25$
- **D.** $0$

> Every child receives $A$ from the father and $B$ from the mother, so
> all are $AB$. In general $P'_{AB} = p_m q_f + p_f q_m$, which equals
> $2pq$ only when allele frequencies in males ($p_m$) and females
> ($p_f$) agree. $0.5$ is $2pq$ with the pooled $p = 0.5$, which wrongly
> assumes HWE is reached in one generation when the sexes differ; it is
> reached one generation later.

## 10. hwe-010 — Carrier frequency for a recessive disease (numerical)
`carrier-frequency` `medium` `draft` `numerical` `verified: run`
*Source: Slide 18 (cystic fibrosis exercise)*

Disease-causing alleles of a recessive disease gene have a combined
frequency of $q = 1/50$; treat them together as a single allele.
Assume Hardy-Weinberg equilibrium.

What proportion of the population are carriers (heterozygous for a
disease allele and a normal allele)? Enter a decimal rounded to three
decimal places.

**Answer:** any value in [0.0385, 0.0405] ✅

> Carriers are heterozygotes: $2pq = 2 \cdot \tfrac{49}{50} \cdot
> \tfrac{1}{50} = \tfrac{98}{2500} = 0.0392$, about 1 in 25. The
> approximation $2q = 0.04$ is also accepted. $q^2 = 0.0004$ is the
> proportion of affected children (1 in 2,500), not carriers.

## 11. hwe-011 — From disease incidence to carriers
`carrier-frequency` `medium` `draft` `verified: run`
*Source: Slide 18 (carriers and affected births under HWE)*

A recessive disease affects 1 in 10,000 newborns. Assume Hardy-Weinberg
equilibrium and a single disease allele.

About what fraction of the population are carriers?

- **A.** 1 in 5,000
- **B.** 1 in 200
- **C.** 1 in 100
- **D.** 1 in 50 **✅**

> Affected births are $q^2 = 10^{-4}$, so $q = 0.01$ and carriers are
> $2pq = 2(0.99)(0.01) \approx 0.02$, about 1 in 50. 1 in 100 is the
> allele frequency $q$, 1 in 200 halves it, and 1 in 5,000 is $2q^2$.

## 12. hwe-012 — Expected heterozygosity with three alleles (Python)
`multiple-alleles` `medium` `draft` `verified: run`
*Source: Slide 19 (multiple alleles: homozygotes p^2, heterozygotes 2 p_A p_B)*

```python
p = {"A": 0.5, "B": 0.3, "C": 0.2}
het = 1 - sum(f**2 for f in p.values())
print(round(het, 2))
```

`p` holds allele frequencies at a locus assumed to be in HWE. What does
the code print?

- **A.** `0.38`
- **B.** `0.62` **✅**
- **C.** `0.31`
- **D.** `0.5`

> Under HWE the homozygote frequencies are $p_A^2 + p_B^2 + p_C^2 =
> 0.25 + 0.09 + 0.04 = 0.38$, so heterozygotes make up $1 - 0.38 = 0.62$,
> the same as $2(p_Ap_B + p_Ap_C + p_Bp_C)$. $0.38$ is the homozygote
> total; $0.31$ sums $p_ip_j$ without the factor 2.

## 13. hwe-013 — Inbreeding and allele frequencies
`inbreeding` `easy` `draft` `true_false` `verified: run`
*Source: Slides 19-20 (inbreeding)*

True or false: in a large population, inbreeding (mating between
relatives) changes genotype frequencies at a locus, but by itself does
not change allele frequencies.

**Answer:** True ✅

> True. Inbreeding makes the two alleles an individual carries more
> likely to be identical by descent, moving individuals from
> heterozygous to homozygous classes symmetrically:
> $P_{AA} = p^2 + Fpq$, $P_{AB} = 2pq(1 - F)$, $P_{BB} = q^2 + Fpq$.
> Then $p_A = P_{AA} + \tfrac12 P_{AB} = p$ for every $F$.

## 14. hwe-014 — Inbreeding and a rare recessive allele
`inbreeding` `hard` `draft` `verified: run`
*Source: Slides 19-20 (inbreeding coefficient F; why inbreeding matters)*

With inbreeding coefficient $F$, the frequency of homozygotes for
allele $B$ (frequency $q$, with $p = 1 - q$) is

$$P_{BB} = q^2 + F\,p\,q .$$

For a rare recessive allele with $q = 0.01$, consider offspring with
$F = 0.01$.

About how many times more common are $BB$ homozygotes among these
offspring than under HWE ($F = 0$)?

- **A.** About 1.01 times
- **B.** About 2 times **✅**
- **C.** About 10 times
- **D.** About 100 times

> $F p q \approx 0.01 \times 0.01 = 10^{-4}$, the same size as
> $q^2 = 10^{-4}$, so $P_{BB}$ roughly doubles (ratio
> $1 + Fp/q = 1.99$). Even small $F$ matters when $q$ is comparable to
> $F$. 1.01 multiplies by $(1 + F)$; 100 is $1/q$.

## 15. hwe-015 — Which cause gives excess heterozygotes?
`causes-of-deviation` `medium` `draft` `verified: no`
*Source: Slide 21 (causes of deviation; which increase heterozygotes)*

A SNP assay is applied to a sample from one population. Each
situation below can make genotype counts deviate from Hardy-Weinberg
proportions.

Which situation is expected to produce *more* heterozygotes than HWE
predicts?

- **A.** The sample pools two groups with different allele frequencies
- **B.** The assay often fails to detect one allele in heterozygotes
- **C.** The sampled population has substantial inbreeding
- **D.** The probe also matches a near-identical copy of the region **✅**

> With a duplicated (homologous) region, a person homozygous $AA$ at one
> copy and $BB$ at the other gives signal from both alleles and is
> called $AB$, inflating heterozygotes. Pooling groups with different
> allele frequencies (population structure), allele dropout and
> inbreeding all reduce heterozygotes relative to HWE.

## 16. hwe-016 — Reading a genotype cluster plot
`genotype-calling` `medium` `draft` `verified: run`
*Source: Slides 31-33 (poor genotype calling; cluster plots)*

![Scatter plot of allele A signal intensity (x-axis, 0 to 8) against allele B signal intensity (y-axis, 0 to 8) for 100 samples. Samples called B/B are drawn as triangles and form one cloud near x = 2, y = 5. Samples called A/B are drawn as squares and form two separate clouds: one near x = 3.6, y = 3.6 and one near x = 5, y = 2. No sample is called A/A. The legend gives the counts: B/B 20, A/B 80.](figures/cluster-plot.png)

The plot shows signal intensities and the genotype calls a calling
algorithm made for one SNP in 100 samples: 20 called B/B, 80 called
A/B and none called A/A.

Which description fits this SNP best?

- **A.** Heterozygote excess: a cluster of A/A samples was called A/B **✅**
- **B.** Heterozygote deficit: A/B samples were called A/A
- **C.** Consistent with HWE: allele A is too rare to see A/A
- **D.** Heterozygote deficit: the sample mixes two populations

> The squares form two clouds; the one with high $A$ and low $B$ signal
> is where $A/A$ samples belong. With these calls,
> $p_B = (2 \cdot 20 + 80)/200 = 0.6$, so HWE predicts
> $2(0.6)(0.4)(100) = 48$ heterozygotes, but 80 are called, a large
> excess, not a deficit. Allele $A$ has frequency $0.4$, so about 16
> $A/A$ samples are expected; their absence signals a calling error.

## 17. hwe-017 — False exclusions from an HWE filter
`gwas-thresholds` `easy` `draft` `verified: run`
*Source: Slide 31 (GWAS HWE thresholds of p < 1e-3 to 1e-6)*

A genome-wide study genotypes 1,000,000 SNPs without error, and every
SNP is truly in Hardy-Weinberg equilibrium. Each SNP is tested for HWE
and excluded if $p < 10^{-6}$. Assume the test's type I error rate
equals its nominal level.

About how many SNPs are excluded by chance?

- **A.** 1 **✅**
- **B.** 10
- **C.** 1,000
- **D.** 50,000

> Expected false exclusions are $10^6 \times 10^{-6} = 1$. A threshold of
> $0.05$ would discard about 50,000 good SNPs, which is why
> genome-wide studies use thresholds between $10^{-3}$ and $10^{-6}$.

## 18. hwe-018 — Where an associated SNP deviates from HWE
`causes-of-deviation` `hard` `draft` `verified: run`
*Source: Slide 21 (association with trait in case-control studies)*

A SNP is perfectly genotyped, and in the general population it is in
Hardy-Weinberg equilibrium. Allele $B$ has a strong recessive effect on
a rare disease: $BB$ individuals have much higher risk than $AA$ or
$AB$. A case-control study samples affected cases and unaffected
controls.

In which sample is a deviation from HWE most likely?

- **A.** Controls only
- **B.** Cases only **✅**
- **C.** Both samples equally
- **D.** Neither sample

> Selecting on disease status enriches cases for $BB$ relative to
> $AB$, so cases show an excess of $BB$ homozygotes. Because the disease
> is rare, unaffected controls are nearly a random population sample
> and stay close to HWE. This is why HWE quality filters are usually
> applied to controls: in cases a deviation can reflect true
> association.

## 19. hwe-019 — Chi-square statistic for HWE (Python)
`chi-square-test` `easy` `draft` `verified: run`
*Source: Slides 22-23 (simple approach: chi-squared test statistic)*

```python
obs = [30, 40, 30]               # counts of AA, AB, BB
n = sum(obs)
p = (2 * obs[0] + obs[1]) / (2 * n)
exp = [n * p**2, 2 * n * p * (1 - p), n * (1 - p)**2]
chi2 = sum((o - e)**2 / e for o, e in zip(obs, exp))
print(round(chi2, 2))
```

What does the code print?

- **A.** `1.0`
- **B.** `4.17`
- **C.** `2.0`
- **D.** `4.0` **✅**

> $p = (60 + 40)/200 = 0.5$, so expected counts are $25, 50, 25$ and
> $\chi^2 = \tfrac{25}{25} + \tfrac{100}{50} + \tfrac{25}{25} = 4.0$.
> $4.17$ divides by the observed counts instead of the expected ones;
> $2.0$ keeps only the heterozygote term; $1.0$ keeps only one
> homozygote term.

## 20. hwe-020 — Degrees of freedom with three alleles
`chi-square-test` `medium` `draft` `verified: run`
*Source: Slide 23 (chi-squared test); slide 19 (multiple alleles)*

A locus has $k = 3$ alleles, so there are 6 genotype classes. A
chi-square goodness-of-fit test of HWE compares the 6 observed genotype
counts with HWE expectations computed from allele frequencies
estimated from the same sample.

How many degrees of freedom does the test have?

- **A.** $1$
- **B.** $2$
- **C.** $3$ **✅**
- **D.** $5$

> Six cells give $6 - 1 = 5$ free counts; estimating $k - 1 = 2$ allele
> frequencies uses 2 more, leaving $3 = k(k-1)/2$. $5$ forgets the
> estimated frequencies, $2$ counts only the frequencies, and $1$ is the
> two-allele case.

## 21. hwe-021 — Exact probability in a tiny sample
`exact-test-probability` `medium` `draft` `verified: run`
*Source: Slides 24-26 (probability of n_AB heterozygotes)*

For a sample of $N$ individuals with $n_A$ copies of allele $A$ and
$n_B = 2N - n_A$ copies of $B$, the probability under HWE of observing
$n_{AB}$ heterozygotes (and so $n_{AA} = (n_A - n_{AB})/2$,
$n_{BB} = (n_B - n_{AB})/2$) is

$$P(N_{AB} = n_{AB} \mid N, n_A) = \frac{2^{n_{AB}}\, N!}{n_{AA}!\, n_{AB}!\, n_{BB}!} \cdot \frac{n_A!\, n_B!}{(2N)!} .$$

Take $N = 2$ individuals and $n_A = n_B = 2$.

What is the probability that both individuals are heterozygous?

- **A.** $\tfrac14$
- **B.** $\tfrac13$
- **C.** $\tfrac23$ **✅**
- **D.** $\tfrac12$

> For $n_{AB} = 2$: $2^2 \cdot \tfrac{2!}{0!\,2!\,0!} \cdot
> \tfrac{2!\,2!}{4!} = 4 \cdot 1 \cdot \tfrac{4}{24} = \tfrac23$; the only
> other outcome, one $AA$ and one $BB$, has $\tfrac13$. Conditioning on
> the observed allele counts makes this differ from the infinite-population
> value $(2pq)^2 = \tfrac14$; $\tfrac12$ is $2pq$ for a single person.

## 22. hwe-022 — Recursive exact-test probabilities (R)
`exact-test-recursion` `hard` `draft` `verified: run`
*Source: Slide 25 (calculation carried out in recursive fashion)*

Going from $n_{AB}$ to $n_{AB} - 2$ heterozygotes (one more $AA$ and one
more $BB$), the exact-test probabilities satisfy

$$\frac{P(n_{AB} - 2)}{P(n_{AB})} = \frac{n_{AB}\,(n_{AB} - 1)}{4\,(n_{AA} + 1)\,(n_{BB} + 1)} ,$$

where $n_{AA}$ and $n_{BB}$ are the counts in the configuration with
$n_{AB}$ heterozygotes. The function below uses this to compute the
whole distribution.

```r
het_probs <- function(N, nA) {
  nB  <- 2 * N - nA                     # assumes nA <= nB
  nAB <- seq(nA, 0, by = -2)            # possible heterozygote counts
  w <- numeric(length(nAB)); w[1] <- 1  # unnormalized weights
  for (i in seq_along(nAB)[-1]) {
    h   <- nAB[i - 1]
    nAA <- (nA - h) / 2
    nBB <- (nB - h) / 2
    w[i] <- w[i - 1] * h * (h - 1) / (4 * (nAA + 1) * (nBB + 1))
  }
  setNames(w / sum(w), nAB)
}
het_probs(N = 3, nA = 2)
```

What does the last line print?

- **A.** ```
  2   0
0.2 0.8
```

- **B.** ```
  2   0
0.8 0.2
```
 **✅**
- **C.** ```
  2   0
0.5 0.5
```

- **D.** ```
        2         0
0.6666667 0.3333333
```


> Start at $n_{AB} = 2$ ($n_{AA} = 0$, $n_{BB} = 1$) with weight 1. The
> ratio to $n_{AB} = 0$ is $\tfrac{2 \cdot 1}{4 \cdot 1 \cdot 2} =
> \tfrac14$, so the weights are $1$ and $0.25$, normalized to $0.8$ and
> $0.2$. Swapping them inverts the ratio; $0.5\ 0.5$ drops the factor 4
> (which comes from $2^{n_{AB}}$); $2/3$ and $1/3$ result from a ratio of
> $\tfrac12$.

## 23. hwe-023 — One-sided exact test for a heterozygote deficit
`exact-test-p-values` `hard` `draft` `verified: run`
*Source: Slides 24 and 28 (one-sided tests; comparison of test statistics)*

For a sample of $N = 100$ individuals with $n_A = 21$ copies of the
minor allele, the exact probabilities of each possible number of
heterozygotes under HWE are:

| $n_{AB}$ | $\le 7$ | 9 | 11 | 13 | 15 | 17 | 19 | 21 |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|
| probability | 0.000001 | 0.000047 | 0.000870 | 0.009375 | 0.059283 | 0.214465 | 0.406355 | 0.309604 |

A sample shows $n_{AB} = 19$. What is the p-value of the one-sided
exact test against the alternative of *too few* heterozygotes?

- **A.** $0.406$
- **B.** $0.716$
- **C.** $0.690$ **✅**
- **D.** $1.000$

> Too few heterozygotes means small $n_{AB}$ is extreme, so the p-value
> is $P(N_{AB} \le 19) = 1 - P(21) = 1 - 0.310 = 0.690$. $0.716$ is the
> upper tail $P(N_{AB} \ge 19)$ (test for excess heterozygotes); $1.000$
> is the two-sided $P_{HWE}$, since 19 is the most likely outcome; $0.406$
> is the probability of the observed value alone.

## 24. hwe-024 — Type I error with a rare allele
`type-i-error` `medium` `draft` `verified: run`
*Source: Slides 23, 29-30 (comparison of type I error rates)*

Consider samples of $N = 1{,}000$ individuals at SNPs truly in HWE whose
minor allele appears only 1 to 100 times in the sample. Each SNP is
tested at nominal level $\alpha = 0.001$ with either the one-degree-of-freedom
chi-square test or the two-sided exact test.

How do the actual type I error rates compare with $\alpha$?

- **A.** Chi-square below $\alpha$; exact test above $\alpha$
- **B.** Chi-square above $\alpha$; exact test below $\alpha$ **✅**
- **C.** Both are close to $\alpha$
- **D.** Both are well above $\alpha$

> With a rare allele the expected count of minor-allele homozygotes is
> tiny, so the chi-square approximation fails and the test rejects too
> often (averaging about $0.009$ here, nine times $\alpha$). The exact
> test sums exact probabilities, so its error never exceeds $\alpha$;
> because the distribution is discrete it is conservative (about
> $0.00035$ here).

## 25. hwe-025 — Which outcomes make up the exact p-value
`exact-test-p-values` `easy` `draft` `verified: run`
*Source: Slides 24 and 27 (exact test: sum outcomes with equal or lesser probability)*

![Bar chart of probability (y-axis, 0 to 0.16) against number of heterozygotes (x-axis, 40 to 76, even values only). The bars form a hump peaking at 58 with a probability of about 0.15 and fall off on both sides, to below 0.01 at 46 and at 72. An arrow labeled Observed points to the bar at 46, whose height is about 0.009.](figures/exact-null.png)

The bars show the exact distribution, under HWE, of the number of
heterozygotes in a sample of 120 individuals with 100 copies of the
minor allele. The observed sample has 46 heterozygotes.

The two-sided exact p-value is the total probability of which bars?

- **A.** Bars at or below 46 heterozygotes
- **B.** Bars at or above 46 heterozygotes
- **C.** Bars no taller than the bar at 46 **✅**
- **D.** Only the bar at 46

> The two-sided exact test sums the probabilities of all outcomes as
> likely as or less likely than the one observed, which here includes
> the bars at 46 and below and the bars from about 72 upward on the
> other side. Bars at or below 46 give the one-sided test for a
> heterozygote deficit; the bar alone ignores more extreme outcomes.

## 26. hwe-026 — A single copy of the minor allele
`exact-test-probability` `medium` `draft` `verified: run`
*Source: Slides 24-25 (exact test conditions on the allele counts)*

A sample of $N$ individuals ($N \ge 2$) contains exactly one copy of
the minor allele, $n_A = 1$. The exact test of HWE conditions on the
observed allele counts.

What is the two-sided exact p-value $P_{HWE}$?

- **A.** $1/(2N)$
- **B.** $1/N$
- **C.** $0.5$
- **D.** $1$ **✅**

> With one copy of $A$, the only possible configuration is one $AB$
> individual and $N - 1$ $BB$ individuals, so $P(N_{AB} = 1) = 1$ and the
> p-value is 1: the data carry no information about HWE. $1/(2N)$ is the
> allele frequency, and $1/N$ is the observed heterozygote frequency.
