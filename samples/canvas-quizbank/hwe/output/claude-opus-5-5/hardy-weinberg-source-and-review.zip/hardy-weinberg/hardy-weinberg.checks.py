# hardy-weinberg.checks.py — run: python3 hardy-weinberg.checks.py
# One section per item id. Also draws figures/cluster-plot.png and
# figures/exact-null.png.
import sys
import os
from fractions import Fraction as Fr
from math import comb, factorial, lgamma, log, exp
from itertools import combinations_with_replacement, product

HERE = os.path.dirname(os.path.abspath(__file__))


def check(item_id, ok):
    if not ok:
        sys.exit(f"check failed: {item_id}")
    print("ok", item_id)


print(sys.version)


def het_dist(N, nA):
    """Exact HWE distribution of the heterozygote count (Levene/Wigginton)."""
    nB = 2 * N - nA
    if nA > nB:
        nA, nB = nB, nA
    out = {}
    for h in range(nA % 2, nA + 1, 2):
        aa, bb = (nA - h) // 2, (nB - h) // 2
        lp = (h * log(2) + lgamma(N + 1) - lgamma(aa + 1) - lgamma(h + 1)
              - lgamma(bb + 1) + lgamma(nA + 1) + lgamma(nB + 1)
              - lgamma(2 * N + 1))
        out[h] = exp(lp)
    return out


def het_dist_exact(N, nA):
    """Same distribution with exact fractions (small N only)."""
    nB = 2 * N - nA
    out = {}
    for h in range(nA % 2, min(nA, nB) + 1, 2):
        aa, bb = (nA - h) // 2, (nB - h) // 2
        out[h] = (Fr(2 ** h * factorial(N), factorial(aa) * factorial(h) * factorial(bb))
                  * Fr(factorial(nA) * factorial(nB), factorial(2 * N)))
    return out


def p_hwe(d, h):
    return sum(p for p in d.values() if p <= d[h] * (1 + 1e-7))


# ---- hwe-001: genotypes at a five-allele locus
def _hwe_001():
    n = 5
    genos = list(combinations_with_replacement(range(n), 2))
    check("hwe-001", len(genos) == 15 == n * (n + 1) // 2
          and n * n == 25 and comb(n, 2) == 10 and n * (n - 1) == 20)
_hwe_001()


# ---- hwe-002: allele frequency from counts (R code; numbers re-checked here, code run in .checks.R)
def _hwe_002():
    pA = (2 * 36 + 48) / (2 * 100)
    check("hwe-002", abs(pA - 0.6) < 1e-12 and (36 + 48) / 100 == 0.84
          and (36 + 48) / 200 == 0.42)
_hwe_002()


# ---- hwe-003: allele frequency at a three-allele locus
def _hwe_003():
    import io, contextlib
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        geno = {"AA": 0.10, "AB": 0.20, "AC": 0.30,
                "BB": 0.05, "BC": 0.15, "CC": 0.20}
        pA = sum(f * g.count("A") / 2 for g, f in geno.items())
        print(round(pA, 2))
    out = buf.getvalue().strip()
    check("hwe-003", out == "0.35" and abs(sum(geno.values()) - 1) < 1e-12
          and round(0.10 + 0.20 + 0.30, 2) == 0.6 and round(0.10 + 0.10, 2) == 0.2)
_hwe_003()


# ---- hwe-004: same allele frequency, different genotypes
def _hwe_004():
    pops = {1: (0.40, 0.20, 0.40), 2: (0.25, 0.50, 0.25)}
    ok = True
    hwe = {}
    for k, (aa, ab, bb) in pops.items():
        p = aa + ab / 2
        ok &= abs(p - 0.5) < 1e-12
        hwe[k] = all(abs(x - y) < 1e-12 for x, y in zip((aa, ab, bb), (p * p, 2 * p * (1 - p), (1 - p) ** 2)))
    check("hwe-004", ok and hwe == {1: False, 2: True})
_hwe_004()


# ---- hwe-005: frequency of AA x AB matings (unordered)
def _hwe_005():
    P = {"AA": Fr(1, 5), "AB": Fr(1, 2), "BB": Fr(3, 10)}
    freq = sum(P[f] * P[m] for f, m in product(P, P) if {f, m} == {"AA", "AB"})
    check("hwe-005", freq == 2 * P["AA"] * P["AB"])
_hwe_005()


# ---- hwe-006: offspring AA frequency equals (P_AA + P_AB/2)^2
def _hwe_006():
    import random
    rng = random.Random(1)
    ok_key = True
    wrong = [0, 0, 0]
    for _ in range(200):
        a, b = sorted([Fr(rng.randint(0, 100), 100), Fr(rng.randint(0, 100), 100)])
        AA, AB = a, b - a
        lhs = AA ** 2 + AA * AB + Fr(1, 4) * AB ** 2
        ok_key &= lhs == (AA + AB / 2) ** 2
        wrong[0] += lhs != (AA + AB) ** 2
        wrong[1] += lhs != AA ** 2 + Fr(1, 4) * AB ** 2
        wrong[2] += lhs != AA * (AA + AB)
        # derive the sum from the mating table too
    P = {"AA": Fr(3, 10), "AB": Fr(2, 5), "BB": Fr(3, 10)}
    seg = {"AA": {"A": 1}, "AB": {"A": Fr(1, 2), "B": Fr(1, 2)}, "BB": {"B": 1}}
    off_AA = sum(P[f] * P[m] * seg[f].get("A", 0) * seg[m].get("A", 0) for f in P for m in P)
    check("hwe-006", ok_key and all(w > 0 for w in wrong)
          and off_AA == P["AA"] ** 2 + P["AA"] * P["AB"] + Fr(1, 4) * P["AB"] ** 2)
_hwe_006()


# ---- hwe-008: heterozygotes after one generation of random mating
def _hwe_008():
    P = {"AA": Fr(4, 5), "AB": Fr(0), "BB": Fr(1, 5)}
    seg = {"AA": {"A": 1}, "AB": {"A": Fr(1, 2), "B": Fr(1, 2)}, "BB": {"B": 1}}
    het = sum(P[f] * P[m] * (seg[f].get("A", 0) * seg[m].get("B", 0) + seg[f].get("B", 0) * seg[m].get("A", 0))
              for f in P for m in P)
    check("hwe-008", het == Fr(32, 100))
_hwe_008()


# ---- hwe-009: sexes with different allele frequencies
def _hwe_009():
    pm, pf = 1, 0           # frequency of A in males, females
    het = pm * (1 - pf) + pf * (1 - pm)
    check("hwe-009", het == 1)
_hwe_009()


# ---- hwe-010: carrier frequency, q = 1/50
def _hwe_010():
    q = Fr(1, 50); p = 1 - q
    carriers = 2 * p * q
    check("hwe-010", carriers == Fr(98, 2500) and 0.0385 <= float(carriers) <= 0.0405
          and 0.0385 <= 0.039 <= 0.0405 and 0.0385 <= 0.04 <= 0.0405
          and not 0.0385 <= float(q * q) <= 0.0405)
_hwe_010()


# ---- hwe-011: 1 in 10,000 affected -> carriers about 1 in 50
def _hwe_011():
    q = 0.01
    carriers = 2 * (1 - q) * q
    check("hwe-011", abs(1 / carriers - 50.5) < 0.1 and abs(1 / (2 * q * q) - 5000) < 1e-6)
_hwe_011()


# ---- hwe-012: expected heterozygosity with three alleles
def _hwe_012():
    import io, contextlib
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        p = {"A": 0.5, "B": 0.3, "C": 0.2}
        het = 1 - sum(f**2 for f in p.values())
        print(round(het, 2))
    alt = 2 * (0.5 * 0.3 + 0.5 * 0.2 + 0.3 * 0.2)
    check("hwe-012", buf.getvalue().strip() == "0.62" and abs(alt - 0.62) < 1e-12
          and round(0.5 * 0.3 + 0.5 * 0.2 + 0.3 * 0.2, 2) == 0.31)
_hwe_012()


# ---- hwe-013: inbreeding leaves allele frequency unchanged
def _hwe_013():
    ok = True
    for p in (Fr(1, 10), Fr(1, 2), Fr(7, 10)):
        q = 1 - p
        for F in (Fr(0), Fr(1, 16), Fr(1, 2), Fr(1)):
            AA, AB, BB = p * p + F * p * q, 2 * p * q * (1 - F), q * q + F * p * q
            ok &= AA + AB + BB == 1 and AA + AB / 2 == p
    check("hwe-013", ok)
_hwe_013()


# ---- hwe-014: inbreeding and a rare recessive allele
def _hwe_014():
    q, F = 0.01, 0.01
    p = 1 - q
    ratio = (q * q + F * p * q) / (q * q)
    check("hwe-014", abs(ratio - 1.99) < 1e-9)
_hwe_014()


# ---- hwe-016: cluster plot figure and the HWE arithmetic in the explanation
def _hwe_016():
    import numpy as np
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    rng = np.random.default_rng(666)
    bb = rng.normal([2.0, 5.0], 0.30, size=(20, 2))
    ab = rng.normal([3.6, 3.6], 0.28, size=(50, 2))
    aa = rng.normal([5.0, 2.0], 0.30, size=(30, 2))   # true A/A, called A/B
    called_ab = np.vstack([ab, aa])
    fig, ax = plt.subplots(figsize=(6.4, 4.4), dpi=100)
    ax.scatter(bb[:, 0], bb[:, 1], marker="^", s=40, facecolor="white",
               edgecolor="black", linewidth=1.1, label="called B/B (20)")
    ax.scatter(called_ab[:, 0], called_ab[:, 1], marker="s", s=30,
               facecolor="0.55", edgecolor="black", linewidth=0.6, label="called A/B (80)")
    ax.set_xlim(0, 8); ax.set_ylim(0, 8)
    ax.set_xlabel("Intensity for allele A", fontsize=11)
    ax.set_ylabel("Intensity for allele B", fontsize=11)
    ax.set_title("Genotype calls for one SNP (A/A called: 0)", fontsize=11)
    ax.grid(True, color="0.88")
    ax.legend(loc="upper right", fontsize=10, frameon=True)
    fig.tight_layout()
    os.makedirs(os.path.join(HERE, "figures"), exist_ok=True)
    fig.savefig(os.path.join(HERE, "figures", "cluster-plot.png"))
    plt.close(fig)
    pB = (2 * 20 + 80) / 200
    exp_het = 2 * pB * (1 - pB) * 100
    exp_aa = (1 - pB) ** 2 * 100
    check("hwe-016", abs(pB - 0.6) < 1e-12 and abs(exp_het - 48) < 1e-9 and abs(exp_aa - 16) < 1e-9)
_hwe_016()


# ---- hwe-017: false exclusions at p < 1e-6
def _hwe_017():
    check("hwe-017", round(1_000_000 * 1e-6) == 1 and round(1_000_000 * 0.05) == 50_000)
_hwe_017()


# ---- hwe-018: case-control sampling and HWE (numerical illustration)
def _hwe_018():
    q = 0.3; p = 1 - q
    pop = {"AA": p * p, "AB": 2 * p * q, "BB": q * q}             # population in HWE
    risk = {"AA": 0.001, "AB": 0.001, "BB": 0.05}                 # recessive, rare disease
    prev = sum(pop[g] * risk[g] for g in pop)
    cases = {g: pop[g] * risk[g] / prev for g in pop}
    ctrls = {g: pop[g] * (1 - risk[g]) / (1 - prev) for g in pop}
    def het_dev(g):   # observed minus HWE-expected heterozygote frequency
        pa = g["AA"] + g["AB"] / 2
        return g["AB"] - 2 * pa * (1 - pa)
    check("hwe-018", prev < 0.01 and het_dev(cases) < -0.1 and abs(het_dev(ctrls)) < 0.005
          and abs(het_dev(cases)) > 30 * abs(het_dev(ctrls)))
_hwe_018()


# ---- hwe-019: chi-square statistic
def _hwe_019():
    import io, contextlib
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        obs = [30, 40, 30]               # counts of AA, AB, BB
        n = sum(obs)
        p = (2 * obs[0] + obs[1]) / (2 * n)
        exp = [n * p**2, 2 * n * p * (1 - p), n * (1 - p)**2]
        chi2 = sum((o - e)**2 / e for o, e in zip(obs, exp))
        print(round(chi2, 2))
    wrong_obs = sum((o - e) ** 2 / o for o, e in zip(obs, exp))
    check("hwe-019", buf.getvalue().strip() == "4.0" and round(wrong_obs, 2) == 4.17)
_hwe_019()


# ---- hwe-020: df with k = 3 alleles
def _hwe_020():
    k = 3
    cells = k * (k + 1) // 2
    check("hwe-020", cells == 6 and cells - 1 - (k - 1) == 3 == k * (k - 1) // 2)
_hwe_020()


# ---- hwe-021: exact probability, N = 2, nA = 2
def _hwe_021():
    d = het_dist_exact(2, 2)
    check("hwe-021", d == {0: Fr(1, 3), 2: Fr(2, 3)})
_hwe_021()


# ---- hwe-022: recursion (R code run in .checks.R); exact values re-checked here
def _hwe_022():
    d = het_dist_exact(3, 2)
    check("hwe-022", d == {0: Fr(1, 5), 2: Fr(4, 5)})
_hwe_022()


# ---- hwe-023: one-sided exact p-value, N = 100, nA = 21, observed 19
def _hwe_023():
    d = het_dist(100, 21)
    table = {9: 0.000047, 11: 0.000870, 13: 0.009375, 15: 0.059283,
             17: 0.214465, 19: 0.406355, 21: 0.309604}
    ok = all(round(d[h], 6) == v for h, v in table.items())
    ok &= round(sum(p for h, p in d.items() if h <= 7), 6) == 0.000001
    p_low = sum(p for h, p in d.items() if h <= 19)
    p_high = sum(p for h, p in d.items() if h >= 19)
    check("hwe-023", ok and round(p_low, 3) == 0.690 and round(p_high, 3) == 0.716
          and round(p_hwe(d, 19), 6) == 1.0)
_hwe_023()


# ---- hwe-024: type I error, N = 1000, minor allele count 1-100, alpha = 0.001
def _hwe_024():
    from scipy.stats import chi2 as chi2dist
    import scipy
    print("scipy", scipy.__version__)
    N, alpha = 1000, 0.001
    ec = ee = 0.0
    for nA in range(1, 101):
        d = het_dist(N, nA)
        p = nA / (2 * N)
        e = [N * p * p, 2 * N * p * (1 - p), N * (1 - p) ** 2]
        for h, ph in d.items():
            o = [(nA - h) // 2, h, (2 * N - nA - h) // 2]
            x2 = sum((a - b) ** 2 / b for a, b in zip(o, e))
            if chi2dist.sf(x2, 1) <= alpha:
                ec += ph
            if p_hwe(d, h) <= alpha:
                ee += ph
    ec /= 100; ee /= 100
    print("  chi-square error", round(ec, 5), " exact error", round(ee, 5))
    check("hwe-024", 0.008 < ec < 0.010 and 0.0003 < ee < 0.0004)
_hwe_024()


# ---- hwe-025: exact null distribution figure, N = 120, nA = 100, observed 46
def _hwe_025():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    d = het_dist(120, 100)
    xs = [h for h in d if 40 <= h <= 76]
    fig, ax = plt.subplots(figsize=(6.4, 4), dpi=100)
    ax.bar(xs, [d[h] for h in xs], width=1.2, color="0.45", edgecolor="black", linewidth=0.5)
    ax.annotate("Observed", xy=(46, d[46] + 0.002), xytext=(41, 0.085), fontsize=11,
                arrowprops=dict(arrowstyle="->", lw=1.2))
    ax.set_xlim(38, 78); ax.set_ylim(0, 0.16)
    ax.set_xlabel("Number of heterozygotes", fontsize=11)
    ax.set_ylabel("Probability", fontsize=11)
    ax.set_title("Exact HWE distribution: N = 120, 100 minor-allele copies", fontsize=11)
    fig.tight_layout()
    fig.savefig(os.path.join(HERE, "figures", "exact-null.png"))
    plt.close(fig)
    mode = max(d, key=d.get)
    tails = sorted(h for h in d if d[h] <= d[46] * (1 + 1e-9))
    upper = [h for h in tails if h > 46]
    check("hwe-025", mode == 58 and abs(d[58] - 0.148) < 0.001 and abs(d[46] - 0.0094) < 0.0001
          and d[72] < 0.01 < d[70] and upper[0] == 72)
_hwe_025()


# ---- hwe-026: a single copy of the minor allele
def _hwe_026():
    ok = all(het_dist_exact(N, 1) == {1: Fr(1)} for N in (2, 5, 50))
    check("hwe-026", ok)
_hwe_026()

print("all checks passed")
