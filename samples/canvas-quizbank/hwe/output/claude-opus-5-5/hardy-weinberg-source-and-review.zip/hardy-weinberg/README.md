# Hardy-Weinberg Equilibrium (Biostatistics 666, lecture 2)

Built 2026-10-10 by the canvas-quizbank skill.

## The two downloads

- `hardy-weinberg.qti.zip`: import this into Canvas (see below).
- `hardy-weinberg-source-and-review.zip`: this folder. Keep it: the YAML is the source for every later change, rebuild and sync.

## Files in this folder

- `hardy-weinberg.yaml`: the bank; edit this, never the QTI file
- `hardy-weinberg.review.md`: every item with its answer marked; unverified items first
- `hardy-weinberg.checks.R`: the code that verified the items (one section per item)
- `hardy-weinberg.checks.py`: the code that verified the items (one section per item)
- `README.md`: this file
- `figures/`: images used by the items

## Summary

- 26 items: 8 easy, 13 medium, 5 hard
- types: 23 multiple_choice, 1 multiple_answers, 1 numerical, 1 true_false
- verified by running code: 24 of 26

Not verified by execution (check these first):

- hwe-007: conceptual: nothing to execute
- hwe-015: conceptual: nothing to execute

## Notes

# Hand-over notes

Source: 666_02.pdf, "Genes in Populations: Hardy Weinberg Equilibrium" (36 slides).
26 draft items (the request was ~25). All `status: draft`.

## Coverage

| section (slides) | items | easy/medium/hard |
|---|---|---|
| Alleles, genotypes, frequencies (7-11) | hwe-001 to 004 | 3/1/0 |
| HWE derivation and assumptions (12-17) | hwe-005 to 009 | 1/3/1 |
| Applying HWE: carriers, multiple alleles, inbreeding (18-20) | hwe-010 to 014 | 1/3/1 |
| Deviations and genotype QC (21, 31-33) | hwe-015 to 018 | 1/2/1 |
| Testing HWE: chi-square and exact test (22-30) | hwe-019 to 026 | 2/4/2 |

Not covered: slides 1-6 and 35-36 (title, previous lecture, reading lists, the
pedigree-error example on slide 5).

## Requested features

- Types: 23 multiple choice, 1 true/false (hwe-013), 1 multiple answers (hwe-007),
  1 numerical (hwe-010).
- **Short answer substituted**: this builder has no short-answer type, so hwe-010
  (CF carrier frequency) is a numerical item accepting 0.0385 to 0.0405. If you
  want it graded as typed text instead, change its type in Canvas after import.
- Images: hwe-016 (genotype cluster plot) and hwe-025 (exact-test null
  distribution), both redrawn from scratch.
- Math: in most items; display equations in hwe-006, hwe-014, hwe-021, hwe-022.
- Code: R in hwe-002 and hwe-022; Python in hwe-003, hwe-012, hwe-019.
- Tables: hwe-004 and hwe-023.

## Verification

R 4.3.3 and Python 3.13 (scipy 1.18). Every code item was run as printed; R output
compared character for character. The exact-test probabilities in hwe-023 and
the type I error rates in hwe-024 were recomputed from scratch and match the
values on slides 28-29 (chi-square 0.0088, exact 0.00035 for N = 1,000, 1-100
minor-allele copies, alpha = 0.001).

`verified: no` (conceptual, nothing to execute): hwe-007 (assumptions),
hwe-015 (which cause gives excess heterozygotes).

## Judgment calls

- hwe-018 (case-control) is checked with an illustrative recessive model
  (q = 0.3, risks 0.001/0.001/0.05), not data from the slides.
- hwe-022 has R printouts as answer options; check that Canvas shows them as
  code blocks.
- Notation is standardized to P_AA, P_AB, P_BB (genotypes) and p_A, p_B
  (alleles) rather than the slides' p11, p12, p22.

## Import into Canvas

- New Quizzes: in a quiz, open **Item Banks**, create a new bank, then **⋮ → Import Content** and upload the `.qti.zip`.
- Classic Quizzes: **Settings → Import Course Content → QTI .zip file**.
- Each item's title starts with its id; its feedback ends with its source.

## After you review it in Canvas

Delete the items that do not fit, then give the agent (with the canvas-quizbank skill) this folder's YAML plus a Canvas export of what is left, or a text file of the remaining titles. It marks kept items `reviewed` and deleted ones `removed`, so they never come back in a rebuild.
