# Biostatistics 666: Hardy-Weinberg Equilibrium Quiz Bank

25 items in the package (8 easy, 12 medium, 5 hard; 20 multiple_choice, 2 multiple_answers, 2 numerical, 1 true_false; 25 draft; verified 22 run, 3 no)

## Check these first

- **hwe-002**: not verified by execution (R runtime not installed in environment; test script provided in hardy-weinberg.checks.R)
- **hwe-011**: not verified by execution (R runtime not installed in environment; test script provided in hardy-weinberg.checks.R)
- **hwe-022**: not verified by execution (R runtime not installed in environment; test script provided in hardy-weinberg.checks.R)

## 1. hwe-001 — Number of distinct genotypes
`genotype-counting` `easy` `draft` `verified: run`
*Source: Slide 9*

At an autosomal locus with $n$ distinct alternative alleles in a diploid organism, how many distinct diploid genotypes are possible?

- **A.** $n^2$
- **B.** $n(n + 1) / 2$ **✅**
- **C.** $2^n$
- **D.** $n(n - 1) / 2$

> With $n$ distinct alleles, there are $n$ distinct homozygous genotypes ($A_i A_i$) and $\binom{n}{2} = \frac{n(n - 1)}{2}$ distinct heterozygous genotypes ($A_i A_j$ with $i \neq j$). Summing these gives $n + \frac{n(n - 1)}{2} = \frac{n(n + 1)}{2}$ total distinct genotypes. $n^2$ incorrectly treats heterozygotes as ordered pairs ($A_i A_j \neq A_j A_i$), while $n(n - 1) / 2$ counts only heterozygotes and omits homozygotes.

## 2. hwe-002 — Allele frequency from counts in R
`allele-frequency` `easy` `draft` `verified: no`
*Source: Slide 11*

Consider the following R code calculating the sample frequency of allele $A$ from diploid genotype counts:

```r
n_AA <- 40
n_AB <- 40
n_BB <- 20
N <- n_AA + n_AB + n_BB
p_A <- (2 * n_AA + n_AB) / (2 * N)
cat(p_A, "\n")
```

What value does this code print?

- **A.** 0.40
- **B.** 0.50
- **C.** 0.60 **✅**
- **D.** 0.80

> The total sample size is $N = 40 + 40 + 20 = 100$ individuals, giving $2N = 200$ total chromosomes. Each $AA$ individual carries two copies of allele $A$ and each $AB$ individual carries one copy, yielding $2(40) + 40 = 120$ copies of allele $A$. Thus $p_A = \frac{120}{200} = 0.60$. A value of $0.40$ represents the frequency of the alternative allele $B$, while $0.50$ would result from incorrectly treating $AA$ and $AB$ as each contributing only one allele copy without chromosome doubling.

## 3. hwe-003 — Hardy-Weinberg equilibrium assumptions
`assumptions` `medium` `draft` `multiple_answers` `verified: run`
*Source: Slide 13*

Which of the following conditions are required for a population to maintain Hardy-Weinberg equilibrium at an autosomal locus? Select all that apply.

- **A.** Random mating with respect to the locus **✅**
- **B.** Sufficiently large population size to prevent genetic drift **✅**
- **C.** Strong directional natural selection favoring the dominant allele
- **D.** Absence of natural selection, migration, and new mutation **✅**
- **E.** Overlapping generations with age-dependent survival rates

> Hardy-Weinberg equilibrium relies on random mating (panmixia), an effectively infinite or very large population size (negating random genetic drift), autosomal inheritance with equal allele frequencies between sexes, and no evolutionary forces altering allele frequencies (no selection, migration, or mutation). Directional selection actively alters allele frequencies away from equilibrium, and non-overlapping generations is a standard assumption of the classic model.

## 4. hwe-004 — Generation to reach equilibrium
`hwe-dynamics` `easy` `draft` `true_false` `verified: run`
*Source: Slide 17*

Under random mating and standard Hardy-Weinberg assumptions, an autosomal biallelic locus reaches Hardy-Weinberg equilibrium genotypic proportions in a single generation, regardless of the initial genotype frequencies in the parental generation.

**Answer:** True ✅

> Under random mating with equal allele frequencies in both sexes, gametes combine at random in proportion to their population frequencies ($p$ and $q$). As shown by the Mendelian segregation table, offspring genotype frequencies become $p^2, 2pq, q^2$ immediately in the first generation of random mating, regardless of whether the parental generation deviated from equilibrium.

## 5. hwe-005 — Heterozygote intercross offspring
`mendelian-segregation` `medium` `draft` `verified: run`
*Source: Slides 14-15*

In a diploid population with alleles $A_1$ and $A_2$, two heterozygous individuals mate ($A_1A_2 \times A_1A_2$). What proportion of their offspring are expected to be heterozygous ($A_1A_2$)?

- **A.** 1/2 **✅**
- **B.** 1/4
- **C.** 1/3
- **D.** 3/4

> Under Mendelian segregation, an intercross between two heterozygotes ($A_1A_2 \times A_1A_2$) produces offspring in the expected ratios $\frac{1}{4} A_1A_1$, $\frac{1}{2} A_1A_2$, and $\frac{1}{4} A_2A_2$. $1/4$ is the expected frequency for either homozygous class, while $3/4$ is the proportion of offspring carrying at least one $A_1$ allele.

## 6. hwe-006 — CFTR carrier frequency
`carrier-calculation` `medium` `draft` `numerical` `verified: run`
*Source: Slide 18*

Suppose the cumulative frequency of recessive disease alleles for the cystic fibrosis (*CFTR*) gene in a population is $q = \frac{1}{50} = 0.02$. Assuming Hardy-Weinberg equilibrium, what is the expected proportion of heterozygous carriers ($2pq$) in this population?

Enter your answer as a decimal rounded to four decimal places (e.g., `0.0350`).

**Answer:** 0.0392 ± 0.0005 ✅

> With disease allele frequency $q = 0.02$, the normal allele frequency is $p = 1 - q = 0.98$. Under Hardy-Weinberg equilibrium, the expected proportion of heterozygous carriers is $2pq = 2(0.98)(0.02) = 0.0392$ (or approximately $3.92\%$). Omitting the factor of 2 yields $pq = 0.0196$, while approximating $p \approx 1$ gives $2q = 0.0400$.

## 7. hwe-007 — CFTR affected birth incidence
`disease-frequency` `easy` `draft` `verified: run`
*Source: Slide 18*

For an autosomal recessive condition where the cumulative frequency of mutant alleles is $q = 1/50$, what is the expected incidence of affected individuals ($q^2$) at birth under Hardy-Weinberg equilibrium?

- **A.** 1 in 2,500 (0.04%) **✅**
- **B.** 1 in 50 (2.0%)
- **C.** 1 in 100 (1.0%)
- **D.** 1 in 5,000 (0.02%)

> An individual must inherit two mutant alleles to be affected by an autosomal recessive disorder. Under Hardy-Weinberg equilibrium, the expected frequency of homozygotes is $q^2 = (1/50)^2 = 1/2500 = 0.0004$ ($0.04\%$). $1/50$ is the allele frequency $q$, while $1/100$ comes from mistakenly halving the allele frequency instead of squaring it.

## 8. hwe-008 — Tri-allelic HWE differences in Python
`multiallelic-hwe` `medium` `draft` `verified: run`
*Source: Slide 19*

Consider the following Python script modeling a tri-allelic locus with allele frequencies $p_A = 0.5$, $p_B = 0.3$, and $p_C = 0.2$ in Hardy-Weinberg equilibrium:

```python
p = {"A": 0.5, "B": 0.3, "C": 0.2}
freq_AB = 2 * p["A"] * p["B"]
freq_CC = p["C"] ** 2
diff = freq_AB - freq_CC
print(round(diff, 2))
```

What value does this script print?

- **A.** 0.16
- **B.** 0.22
- **C.** 0.30
- **D.** 0.26 **✅**

> Under multi-allelic HWE, the expected frequency of heterozygotes $A/B$ is $2 p_A p_B = 2(0.5)(0.3) = 0.30$. The expected frequency of homozygotes $C/C$ is $p_C^2 = (0.2)^2 = 0.04$. The difference is $0.30 - 0.04 = 0.26$. Forgetting the factor of 2 in heterozygote frequency yields $p_A p_B - p_C^2 = 0.15 - 0.04 = 0.11$, and forgetting to square $p_C$ gives $0.30 - 0.20 = 0.10$.

## 9. hwe-009 — Inbreeding impact on genotype frequencies
`inbreeding` `medium` `draft` `verified: run`
*Source: Slides 19-20*

In a population with inbreeding coefficient $F > 0$ and allele frequencies $p$ and $q$, how do the expected genotype frequencies compare to classical Hardy-Weinberg proportions?

- **A.** Heterozygotes increase by 2pqF while homozygotes decrease equally.
- **B.** Heterozygotes decrease to 2pq(1 - F) while homozygotes increase by pqF. **✅**
- **C.** All genotype frequencies remain identical because allele frequencies do not change.
- **D.** Homozygotes decrease to p^2(1 - F) and q^2(1 - F) while heterozygotes double.

> Inbreeding causes mating between relatives, which increases identity-by-descent. The genotype frequencies under inbreeding become $p^2 + Fpq$ for $AA$, $2pq(1 - F)$ for $AB$, and $q^2 + Fpq$ for $BB$. Consequently, heterozygosity is reduced by a fraction $F$, and both homozygote classes are correspondingly elevated by $Fpq$.

## 10. hwe-010 — Chi-square test degrees of freedom
`chi-square-df` `easy` `draft` `numerical` `verified: run`
*Source: Slide 23*

When performing a Pearson chi-squared goodness-of-fit test for Hardy-Weinberg equilibrium at a single autosomal biallelic locus with 3 possible genotypes, how many degrees of freedom does the asymptotic test statistic have?

Enter an integer.

**Answer:** 1 ✅

> The degrees of freedom for a goodness-of-fit test is calculated as $\text{df} = k - 1 - m$, where $k$ is the number of genotype classes ($k = 3$: $AA, AB, BB$), 1 degree of freedom is lost because the expected counts must sum to the total sample size $N$, and $m = 1$ parameter (the allele frequency $p$) is estimated from the sample data. Therefore, $\text{df} = 3 - 1 - 1 = 1$.

## 11. hwe-011 — Expected heterozygote count in R
`expected-counts` `medium` `draft` `verified: no`
*Source: Slides 22-23*

Consider the following R code computing expected genotype counts under Hardy-Weinberg equilibrium:

```r
counts <- c(AA = 50, AB = 30, BB = 20)
N <- sum(counts)
p <- (2 * counts["AA"] + counts["AB"]) / (2 * N)
q <- 1 - p
exp_AB <- 2 * N * p * q
cat(exp_AB, "\n")
```

What value does this code print?

- **A.** 30.0
- **B.** 42.25
- **C.** 49.0
- **D.** 45.5 **✅**

> The total sample size is $N = 50 + 30 + 20 = 100$. The allele frequency of $A$ is $p = \frac{2(50) + 30}{200} = \frac{130}{200} = 0.65$, and $q = 1 - 0.65 = 0.35$. The expected number of heterozygotes under HWE is $E(AB) = 2 N p q = 2(100)(0.65)(0.35) = 200(0.2275) = 45.5$. $30.0$ is the observed count, while $42.25$ corresponds to $N p^2$.

## 12. hwe-012 — Limitation of chi-squared test
`test-comparison` `easy` `draft` `verified: run`
*Source: Slide 23*

Why is the asymptotic Pearson $\chi^2$ goodness-of-fit test often unreliable for evaluating Hardy-Weinberg equilibrium in genetic association studies?

- **A.** It requires knowledge of parental genotypes that are rarely available in population cohorts.
- **B.** It assumes non-random mating and inappropriately inflates the degrees of freedom.
- **C.** The asymptotic continuous approximation fails when an allele is rare and expected cell counts are small. **✅**
- **D.** It cannot be mathematically formulated for autosomal loci with more than two alleles.

> The Pearson $\chi^2$ test relies on large-sample asymptotic theory. When a minor allele is rare, the expected count of the rare homozygote class ($N q^2$) can be very small (often $< 5$), causing the discrete test statistic distribution to diverge substantially from the theoretical continuous $\chi^2_1$ distribution and leading to inaccurate Type I error rates.

## 13. hwe-013 — Exact test conditional probability formula
`exact-test-probability` `hard` `draft` `verified: run`
*Source: Slide 25*

In the exact test of genotypic proportions conditional on total sample size $N$ and minor allele count $n_A$ (Wigginton et al., 2005), which expression gives the conditional probability of observing $n_{AB}$ heterozygotes?

- **A.** $$P(N_{AB} = n_{AB} \mid N, n_A) = \frac{2^{n_{AB}} N!}{n_{AA}! n_{AB}! n_{BB}!} \cdot \frac{n_A! n_B!}{(2N)!}$$ **✅**
- **B.** $$P(N_{AB} = n_{AB} \mid N, n_A) = \frac{N!}{n_{AA}! n_{AB}! n_{BB}!} \cdot \frac{n_A! n_B!}{(2N)!}$$
- **C.** $$P(N_{AB} = n_{AB} \mid N, n_A) = \frac{2^{n_{AB}} (2N)!}{n_A! n_B!} \cdot \frac{n_{AA}! n_{AB}! n_{BB}!}{N!}$$
- **D.** $$P(N_{AB} = n_{AB} \mid N, n_A) = \frac{(2N)!}{2^{n_{AB}} N!} \cdot \frac{n_{AA}! n_{BB}!}{n_A! n_B!}$$

> The total number of rearrangements of $2N$ alleles into $n_A$ and $n_B$ copies is $\frac{(2N)!}{n_A! n_B!}$. The number of arrangements that yield $n_{AA}, n_{AB}, n_{BB}$ genotypes is $\frac{2^{n_{AB}} N!}{n_{AA}! n_{AB}! n_{BB}!}$, where $2^{n_{AB}}$ accounts for the two internal allele orders within each heterozygote. Taking the ratio gives $\frac{2^{n_{AB}} N!}{n_{AA}! n_{AB}! n_{BB}!} \cdot \frac{n_A! n_B!}{(2N)!}$. Omitting $2^{n_{AB}}$ ignores the distinguishable configurations of heterozygotes.

## 14. hwe-014 — Heterozygote count step size
`exact-test-recursion` `hard` `draft` `verified: run`
*Source: Slide 25*

In an exact test of genotypic proportions where total sample size $N$ and minor allele count $n_A$ are held fixed, by what step size does the number of heterozygotes $n_{AB}$ change between adjacent possible sample configurations?

- **A.** 1
- **B.** 2 **✅**
- **C.** 3
- **D.** 4

> Because $n_A = 2 n_{AA} + n_{AB}$ is fixed, changing $n_{AA}$ by 1 requires changing $n_{AB}$ by 2 to keep $n_A$ invariant (for example, converting one $AA$ and one $BB$ individual into two $AB$ heterozygotes). Thus, the parity of $n_{AB}$ is fixed by the parity of $n_A$, and adjacent possible outcomes always differ by exactly 2 heterozygotes.

## 15. hwe-015 — Recursive probability ratio in Python
`exact-test-recursion` `hard` `draft` `verified: run`
*Source: Slides 25-26*

Consider the following Python function computing the ratio of probabilities between adjacent configurations $n_{AB} + 2$ and $n_{AB}$ in the HWE exact test:

```python
def prob_ratio(n_AA, n_AB, n_BB):
    numerator = 4 * n_AA * n_BB
    denominator = (n_AB + 1) * (n_AB + 2)
    return numerator / denominator

ratio = prob_ratio(n_AA=4, n_AB=2, n_BB=4)
print(round(ratio, 2))
```

What value does this code print?

- **A.** 1.33
- **B.** 2.67
- **C.** 4.00
- **D.** 5.33 **✅**

> Using the recurrence relation for the exact test, the ratio $P(n_{AB} + 2) / P(n_{AB})$ equals $\frac{4 n_{AA} n_{BB}}{(n_{AB} + 1)(n_{AB} + 2)}$. For $n_{AA} = 4, n_{AB} = 2, n_{BB} = 4$, the numerator is $4(4)(4) = 64$ and the denominator is $(2 + 1)(2 + 2) = 3 \times 4 = 12$. The ratio is $\frac{64}{12} = \frac{16}{3} \approx 5.33$. Failing to include the factor of 4 yields $\frac{16}{12} = 1.33$.

## 16. hwe-016 — Exact test p-value calculation
`exact-test-pvalue` `medium` `draft` `verified: run`
*Source: Slide 24*

How is the two-sided p-value ($P_{HWE}$) calculated in the exact test of genotypic proportions?

- **A.** By doubling the tail area under the standard normal curve beyond the observed test statistic value.
- **B.** By summing probabilities of all possible configurations with probability less than or equal to observed. **✅**
- **C.** By integrating the continuous chi-squared probability density function with one degree of freedom.
- **D.** By computing the point probability of observing exactly the sample heterozygote count under random mating.

> Analogous to Fisher's exact test for contingency tables, the two-sided p-value for the exact test of genotypic proportions is defined as $P_{HWE} = \sum_{n^*_{AB}} I\left[P(n^*_{AB}) \le P(n_{AB}^{obs})\right] P(n^*_{AB})$. This sums the conditional probabilities of all outcomes that are as extreme as or less probable than the observed data. Doubling the point probability assumes symmetry that does not hold for discrete asymmetric distributions.

## 17. hwe-017 — Type I error rate periodicity
`type-1-error-rate` `hard` `draft` `verified: run`
*Source: Slide 30*

![Type I error rate comparison between exact test and chi-squared test as minor allele count increases](figures/type1-error-periodic.png)

The plot above shows the actual Type I error rate for the exact test (red) and the $\chi^2$ test (blue) at a nominal significance level $\alpha = 0.05$ across minor allele counts. What causes the pronounced periodic oscillation observed in the Type I error rate?

- **A.** Periodic variations in sequencing machine temperature across different batches.
- **B.** Fluctuations in recombination frequency across distinct genomic windows.
- **C.** The discrete lattice of possible heterozygote counts that increments in steps of 2. **✅**
- **D.** Overlapping generations creating cyclical age cohort effects in the sample.

> Because sample size $N$ and minor allele count $n_A$ are fixed integers, the possible number of heterozygotes $n_{AB}$ can only take discrete values that advance in steps of 2. As the minor allele count increases, the rejection region expands discontinuously as individual discrete probability points cross the $\alpha$ threshold, generating a characteristic periodic sawtooth pattern in the actual Type I error rate.

## 18. hwe-018 — Most common cause of HWE deviation
`qc-causes` `easy` `draft` `verified: run`
*Source: Slide 31*

In modern genome-wide association studies (GWAS), what is the most common real-world cause of a genetic marker deviating significantly from Hardy-Weinberg equilibrium?

- **A.** Poor genotype calling and technical genotyping artifacts **✅**
- **B.** Strong natural selection acting on the disease phenotype
- **C.** Recent population bottlenecks occurring over several generations
- **D.** Non-random mating based on morphological assortative mating

> In practical genetic studies, the vast majority of significant deviations from HWE are caused by technical artifacts, such as poorly separated fluorescence clusters, primer failure, or non-specific probe hybridization. While biological factors such as population substructure or selection can cause deviations, technical calling errors vastly outnumber true biological deviations across hundreds of thousands of assayed markers.

## 19. hwe-019 — Interpreting genotype cluster plots
`cluster-plots` `medium` `draft` `verified: run`
*Source: Slide 32*

![Genotype cluster plots comparing bad and good genotype calling](figures/cluster-plots.png)

The image above displays two genotype cluster plots showing probe intensities for Allele A (x-axis) versus Allele B (y-axis). Which technical issue is clearly visible in the left plot ("Bad Genotype Cluster Plot")?

- **A.** All three genotypes form perfectly distinct, non-overlapping clusters.
- **B.** The homozygote A/A cluster is missing and erroneously merged into the heterozygous A/B cluster. **✅**
- **C.** All samples exhibit zero hybridization intensity for both allele probes.
- **D.** The homozygote B/B cluster contains more than 99% of all assayed individuals.

> In the "Good Genotype Cluster Plot" on the right, three distinct clusters correspond to $B/B$ (green), $A/B$ (red), and $A/A$ (blue). In the "Bad Genotype Cluster Plot" on the left, the blue $A/A$ homozygote cluster is completely missing because automated clustering failed to separate $A/A$ from $A/B$, erroneously classifying homozygous individuals as heterozygotes and generating severe HWE deviation.

## 20. hwe-020 — Causes of heterozygote excess
`deviation-direction` `medium` `draft` `multiple_answers` `verified: run`
*Source: Slide 21*

Deviations from Hardy-Weinberg equilibrium can produce either an excess or a deficiency of heterozygotes. Which of the following factors typically cause an observed *excess* of heterozygotes? Select all that apply.

- **A.** Unintended co-hybridization or co-amplification of homologous genomic regions **✅**
- **B.** Population stratification (mixing distinct subpopulations with different allele frequencies)
- **C.** Inbreeding resulting from consanguineous matings
- **D.** Overdominant natural selection favoring heterozygous individuals (heterozygote advantage) **✅**

> An excess of heterozygotes occurs when probes unintentionally bind to two paralogous or duplicated genomic loci (making nearly every individual appear heterozygous), or under balancing/overdominant selection where heterozygotes have higher fitness. Conversely, population stratification (the Wahlund effect) and inbreeding both systematically lead to a deficiency of heterozygotes and an excess of homozygotes.

## 21. hwe-021 — GWAS HWE quality control in Python
`qc-gwas` `medium` `draft` `verified: run`
*Source: Slide 31*

In genome-wide quality control, markers failing HWE tests below a threshold are filtered out. Consider the following Python snippet:

```python
pvals = {
    "rs101": 0.45,
    "rs102": 1e-7,
    "rs103": 0.002,
    "rs104": 3e-4,
    "rs105": 1e-8,
}
threshold = 1e-5
retained = [snp for snp, p in pvals.items() if p >= threshold]
print(len(retained))
```

What number does this snippet print?

- **A.** 1
- **B.** 2
- **C.** 3 **✅**
- **D.** 4

> The threshold is $10^{-5} = 0.00001$. Comparing each p-value: `rs101` ($0.45 \ge 10^{-5}$, retained), `rs102` ($10^{-7} < 10^{-5}$, removed), `rs103` ($0.002 \ge 10^{-5}$, retained), `rs104` ($3 \times 10^{-4} = 0.0003 \ge 10^{-5}$, retained), and `rs105` ($10^{-8} < 10^{-5}$, removed). Thus, exactly 3 SNPs (`rs101`, `rs103`, `rs104`) are retained.

## 22. hwe-022 — HWE filtering in case-control studies
`qc-gwas` `medium` `draft` `verified: no`
*Source: Slides 21, 31*

In a case-control genome-wide association study, why is Hardy-Weinberg equilibrium quality control filtering routinely performed on the *control* group rather than the affected case group?

- **A.** Control samples have substantially higher genotyping call rates than affected case samples across platforms.
- **B.** Genotyping software automatically disables exact test calculations when disease affection status is provided.
- **C.** Controls represent an unselected population sample with zero historical migrations or assortative mating.
- **D.** True disease-susceptibility loci can naturally deviate from HWE among cases due to association with disease. **✅**

> When a genetic variant confers disease risk, ascertainment into the case group alters genotype proportions away from population Hardy-Weinberg equilibrium. Filtering cases for HWE deviation risks mistakenly discarding genuine disease susceptibility loci. In contrast, population controls (or unselected cohorts) are expected to adhere to HWE unless technical artifacts or severe stratification are present.

## 23. hwe-023 — Permutations of 2N alleles
`combinatorics` `medium` `draft` `verified: run`
*Source: Slide 26*

In the derivation of the exact test of genotypic proportions, how many distinct arrangements can be formed from $2N$ total alleles consisting of $n_A$ copies of allele $A$ and $n_B$ copies of allele $B$?

- **A.** $$\frac{(2N)!}{n_A! n_B!}$$ **✅**
- **B.** $$\frac{N!}{n_A! n_B!}$$
- **C.** $$\frac{(2N)!}{2^{n_{AB}} n_A! n_B!}$$
- **D.** $$\frac{n_A! n_B!}{(2N)!}$$

> The number of distinct ways to arrange $2N$ items where $n_A$ are of type $A$ and $n_B$ are of type $B$ is given by the multiset permutation formula $\binom{2N}{n_A} = \frac{(2N)!}{n_A! n_B!}$. Using $N!$ mistakenly counts diploid individuals rather than total alleles, while $\frac{n_A! n_B!}{(2N)!}$ is the inverse probability.

## 24. hwe-024 — Wahlund effect on heterozygosity
`population-structure` `hard` `draft` `verified: run`
*Source: Slides 21, 34*

When two isolated subpopulations with different allele frequencies ($p_1 \neq p_2$) are pooled together and analyzed as a single homogenous population, what is the systematic consequence on genotypic proportions (the Wahlund effect)?

- **A.** An overall excess of heterozygotes and a deficit of homozygotes relative to HWE.
- **B.** No change in genotype proportions because the pooled mean allele frequency is conserved.
- **C.** A complete loss of homozygous genotypes across all assayed loci.
- **D.** An overall deficit of heterozygotes and an excess of homozygotes relative to HWE. **✅**

> The Wahlund effect demonstrates that pooling subpopulations with differing allele frequencies produces a reduction in observed heterozygosity equal to $2 \text{Var}(p)$ and a corresponding increase in homozygosity. Specifically, the mean heterozygote frequency is $\overline{2 p_i q_i} = 2 \bar{p} \bar{q} - 2 \text{Var}(p) < 2 \bar{p} \bar{q}$. Thus, unrecognized population structure always creates an apparent deficit of heterozygotes.

## 25. hwe-025 — Chi-square goodness-of-fit statistic
`chi-square-statistic` `easy` `draft` `verified: run`
*Source: Slide 23*

For a sample with observed genotype counts $O_g$ and expected genotype counts $E_g$ under Hardy-Weinberg equilibrium across all genotypes $g \in \{AA, AB, BB\}$, which formula represents the Pearson goodness-of-fit test statistic?

- **A.** $$\chi^2 = \sum_{g} \frac{O_g - E_g}{E_g}$$
- **B.** $$\chi^2 = \sum_{g} \frac{(O_g - E_g)^2}{O_g}$$
- **C.** $$\chi^2 = \sum_{g} \frac{(O_g - E_g)^2}{E_g}$$ **✅**
- **D.** $$\chi^2 = \sum_{g} \frac{|O_g - E_g|}{\sqrt{E_g}}$$

> The Pearson $\chi^2$ goodness-of-fit statistic sums the squared deviations between observed and expected counts, normalized by the expected counts: $\chi^2 = \sum_{g} \frac{(O_g - E_g)^2}{E_g}$. Dividing by observed counts ($O_g$) is a common error, while omitting the square produces a sum of signed differences that identically equals zero.
