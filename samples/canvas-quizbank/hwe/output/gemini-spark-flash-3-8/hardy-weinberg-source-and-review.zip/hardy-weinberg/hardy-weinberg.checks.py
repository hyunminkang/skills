#!/usr/bin/env python3
"""Verification checks for Hardy-Weinberg equilibrium quiz bank items.
Run: python3 hardy-weinberg.checks.py
"""
import sys
import math
from pathlib import Path
from PIL import Image

def check(item_id, condition, msg=""):
    if not condition:
        sys.exit(f"FAILED check for {item_id}: {msg}")
    print(f"ok {item_id}")

print(f"Python version: {sys.version.split()[0]}")

# ---- hwe-001: Number of distinct genotypes
def _hwe_001():
    # For n=2: AA, AB, BB -> 3
    # For n=3: AA, BB, CC, AB, AC, BC -> 6
    for n in [2, 3, 5, 10]:
        homo = n
        hetero = (n * (n - 1)) // 2
        total = (n * (n + 1)) // 2
        check("hwe-001", homo + hetero == total, f"failed for n={n}")
_hwe_001()

# ---- hwe-003: Hardy-Weinberg equilibrium assumptions
def _hwe_003():
    # Required: random mating (0), large population (1), absence of selection/migration/mutation (3)
    answer = [0, 1, 3]
    check("hwe-003", set(answer) == {0, 1, 3})
_hwe_003()

# ---- hwe-004: Generation to reach equilibrium
def _hwe_004():
    # Reached in one generation under random mating
    check("hwe-004", True)
_hwe_004()

# ---- hwe-005: Heterozygote intercross offspring
def _hwe_005():
    # A1A2 x A1A2 -> 1/4 A1A1, 1/2 A1A2, 1/4 A2A2
    # Heterozygote proportion is 0.5 (1/2)
    check("hwe-005", 2 * 0.5 * 0.5 == 0.5)
_hwe_005()

# ---- hwe-006: CFTR carrier frequency
def _hwe_006():
    q = 1 / 50
    p = 1 - q
    carrier_freq = 2 * p * q
    check("hwe-006", round(carrier_freq, 4) == 0.0392, f"carrier_freq = {carrier_freq}")
_hwe_006()

# ---- hwe-007: CFTR affected birth incidence
def _hwe_007():
    q = 1 / 50
    affected_freq = q ** 2
    check("hwe-007", round(affected_freq, 4) == 0.0004, f"affected_freq = {affected_freq}")
    check("hwe-007", 1 / affected_freq == 2500)
_hwe_007()

# ---- hwe-008: Tri-allelic HWE differences in Python
def _hwe_008():
    p = {"A": 0.5, "B": 0.3, "C": 0.2}
    freq_AB = 2 * p["A"] * p["B"]
    freq_CC = p["C"] ** 2
    diff = freq_AB - freq_CC
    check("hwe-008", round(diff, 2) == 0.26, f"diff = {diff}")
_hwe_008()

# ---- hwe-009: Inbreeding impact on genotype frequencies
def _hwe_009():
    # Genotype frequencies under inbreeding:
    # P(AA) = p^2 + F*p*q
    # P(AB) = 2*p*q*(1 - F)
    # P(BB) = q^2 + F*p*q
    p, q, F = 0.6, 0.4, 0.1
    p_AA = p**2 + F*p*q
    p_AB = 2*p*q*(1 - F)
    p_BB = q**2 + F*p*q
    check("hwe-009", math.isclose(p_AA + p_AB + p_BB, 1.0))
    check("hwe-009", p_AB < 2*p*q)
_hwe_009()

# ---- hwe-010: Chi-square test degrees of freedom
def _hwe_010():
    # 3 genotypes - 1 sum constraint - 1 parameter (p) = 1 df
    df = 3 - 1 - 1
    check("hwe-010", df == 1)
_hwe_010()

# ---- hwe-012: Limitation of chi-squared test
def _hwe_012():
    # When rare allele count is low, expected counts < 5 cause asymptotic failure
    check("hwe-012", True)
_hwe_012()

# ---- hwe-013: Exact test conditional probability formula
def _hwe_013():
    # Wigginton et al. 2005 formula:
    # P(N_AB = n_AB | N, n_A) = (2^n_AB * N! / (n_AA! n_AB! n_BB!)) * (n_A! n_B! / (2N)!)
    N = 10
    n_AA, n_AB, n_BB = 4, 2, 4
    n_A = 2 * n_AA + n_AB
    n_B = 2 * n_BB + n_AB
    
    ways_sample = (2**n_AB * math.factorial(N)) / (math.factorial(n_AA) * math.factorial(n_AB) * math.factorial(n_BB))
    ways_total = math.factorial(2*N) / (math.factorial(n_A) * math.factorial(n_B))
    p = ways_sample / ways_total
    check("hwe-013", 0 < p < 1)
_hwe_013()

# ---- hwe-014: Heterozygote count step size
def _hwe_014():
    # n_A = 2*n_AA + n_AB
    # If n_AA -> n_AA - 1, then n_AB -> n_AB + 2 to keep n_A fixed
    # Step size is strictly 2
    check("hwe-014", True)
_hwe_014()

# ---- hwe-015: Recursive probability ratio in Python
def _hwe_015():
    def prob_ratio(n_AA, n_AB, n_BB):
        numerator = 4 * n_AA * n_BB
        denominator = (n_AB + 1) * (n_AB + 2)
        return numerator / denominator

    ratio = prob_ratio(n_AA=4, n_AB=2, n_BB=4)
    check("hwe-015", round(ratio, 2) == 5.33, f"ratio = {ratio}")
_hwe_015()

# ---- hwe-016: Exact test p-value calculation
def _hwe_016():
    # P_HWE = sum of P(n_AB) for all outcomes with P(n_AB) <= P_obs
    check("hwe-016", True)
_hwe_016()

# ---- hwe-017: Type I error rate periodicity
def _hwe_017():
    fig_path = Path("quizbank/hardy-weinberg/figures/type1-error-periodic.png")
    check("hwe-017", fig_path.is_file(), "figure file missing")
_hwe_017()

# ---- hwe-018: Most common cause of HWE deviation
def _hwe_018():
    # Poor genotype calling / technical artifacts
    check("hwe-018", True)
_hwe_018()

# ---- hwe-019: Interpreting genotype cluster plots
def _hwe_019():
    fig_path = Path("quizbank/hardy-weinberg/figures/cluster-plots.png")
    check("hwe-019", fig_path.is_file(), "figure file missing")
_hwe_019()

# ---- hwe-020: Causes of heterozygote excess
def _hwe_020():
    # Homologous regions (0) and balancing selection (3) cause excess
    check("hwe-020", True)
_hwe_020()

# ---- hwe-021: GWAS HWE quality control in Python
def _hwe_021():
    pvals = {
        "rs101": 0.45,
        "rs102": 1e-7,
        "rs103": 0.002,
        "rs104": 3e-4,
        "rs105": 1e-8,
    }
    threshold = 1e-5
    retained = [snp for snp, p in pvals.items() if p >= threshold]
    check("hwe-021", len(retained) == 3, f"retained: {retained}")
_hwe_021()

# ---- hwe-023: Permutations of 2N alleles
def _hwe_023():
    # Multiset permutations: (2N)! / (n_A! * n_B!)
    N = 5
    n_A, n_B = 4, 6
    perms = math.factorial(2 * N) // (math.factorial(n_A) * math.factorial(n_B))
    check("hwe-023", perms == 210)
_hwe_023()

# ---- hwe-024: Wahlund effect on heterozygosity
def _hwe_024():
    # Two subpopulations with p1=0.8 and p2=0.2 of equal size
    p1, p2 = 0.8, 0.2
    p_bar = (p1 + p2) / 2 # 0.5
    h_sub = 0.5 * (2 * p1 * (1 - p1)) + 0.5 * (2 * p2 * (1 - p2)) # 0.5*0.32 + 0.5*0.32 = 0.32
    h_pooled = 2 * p_bar * (1 - p_bar) # 2 * 0.5 * 0.5 = 0.50
    # h_sub < h_pooled, meaning pooled subpopulation heterozygosity is deficient
    check("hwe-024", h_sub < h_pooled)
_hwe_024()

# ---- hwe-025: Chi-square goodness-of-fit statistic
def _hwe_025():
    # sum((O_g - E_g)^2 / E_g)
    check("hwe-025", True)
_hwe_025()

print("All Python checks passed successfully!")
