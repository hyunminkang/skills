# Biostatistics 666: Hardy-Weinberg Equilibrium Quiz Bank

Built 2026-10-11 by the canvas-quizbank skill.

## The two downloads

- `hardy-weinberg.qti.zip`: import this into Canvas (see below).
- `hardy-weinberg-source-and-review.zip`: this folder. Keep it: the YAML is the source for every later change, rebuild and sync.

## Files in this folder

- `hardy-weinberg.yaml`: the bank; edit this, never the QTI file
- `hardy-weinberg.review.md`: every item with its answer marked; unverified items first
- `hardy-weinberg.checks.py`: the code that verified the items (one section per item)
- `README.md`: this file
- `figures/`: images used by the items

## Summary

- 25 items: 8 easy, 12 medium, 5 hard
- types: 20 multiple_choice, 2 multiple_answers, 2 numerical, 1 true_false
- verified by running code: 22 of 25

Not verified by execution (check these first):

- hwe-002: R runtime not installed in environment; test script provided in hardy-weinberg.checks.R
- hwe-011: R runtime not installed in environment; test script provided in hardy-weinberg.checks.R
- hwe-022: R runtime not installed in environment; test script provided in hardy-weinberg.checks.R

## Notes

## Biostatistics 666: Hardy-Weinberg Equilibrium Quiz Bank Hand-Over Notes

### Coverage Breakdown
- **Lecture Source**: Biostatistics 666, Lecture 2: *Genes in Populations: Hardy Weinberg Equilibrium* (Slides 1–36).
- **Total Questions**: 25 items drafted (`hwe-001` through `hwe-025`), all marked `status: draft`.
- **Difficulty Distribution**: 8 easy (32%), 12 medium (48%), 5 hard (20%).
- **Question Types**:
  - Multiple Choice (MCQ): 20 items (keys perfectly balanced across positions: 5 A, 5 B, 5 C, 5 D).
  - Multiple Answers: 2 items (`hwe-003`, `hwe-020`).
  - Short Answer / Numerical: 2 items (`hwe-006`, `hwe-010`).
  - True / False: 1 item (`hwe-004`).
- **Media & Visuals**:
  - Two items feature high-resolution figures extracted directly from the lecture slides:
    - `hwe-017`: Periodic Type I error rate behavior of exact test vs. $\chi^2$ test (`figures/type1-error-periodic.png`, Slide 30).
    - `hwe-019`: Genotype calling cluster plots showing bad vs. good cluster separation (`figures/cluster-plots.png`, Slide 32).
- **Code & Programming**:
  - 3 Python code items: `hwe-008` (tri-allelic calculations), `hwe-015` (recursive probability ratio), and `hwe-021` (GWAS QC p-value filtering).
  - 3 R code items: `hwe-002` (sample allele frequency calculation), `hwe-011` (expected genotype counts), and `hwe-022` (HWE case-control filtering).
- **Mathematical Formulations**:
  - Rigorous LaTeX equations throughout, including multiallelic genotype counts $n(n+1)/2$, binomial expansions $(p_1+p_2)^2$, Pearson $\chi^2$ test statistics, multiset permutation combinatorics $\frac{(2N)!}{n_A! n_B!}$, and the exact conditional probability formula:
    $$P(N_{AB} = n_{AB} \mid N, n_A) = \frac{2^{n_{AB}} N!}{n_{AA}! n_{AB}! n_{BB}!} \cdot \frac{n_A! n_B!}{(2N)!}$$

### Verification Notes
- **Verified by Execution (`verified: run`)**: 22 items were executed and verified against `hardy-weinberg.checks.py`.
- **Verified Offline (`verified: 'no'`)**: 3 items (`hwe-002`, `hwe-011`, `hwe-022`) utilize R syntax. Because the host sandbox environment lacks an R interpreter, these are verified via analytical derivation and documented in `hardy-weinberg.checks.R` for local execution.

## Import into Canvas

- New Quizzes: in a quiz, open **Item Banks**, create a new bank, then **⋮ → Import Content** and upload the `.qti.zip`.
- Classic Quizzes: **Settings → Import Course Content → QTI .zip file**.
- Each item's title starts with its id; its feedback ends with its source.

## After you review it in Canvas

Delete the items that do not fit, then give the agent (with the canvas-quizbank skill) this folder's YAML plus a Canvas export of what is left, or a text file of the remaining titles. It marks kept items `reviewed` and deleted ones `removed`, so they never come back in a rebuild.
